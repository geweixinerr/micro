package com.js.port.message;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PsysMessageApplicationTests {

	@Test
	void contextLoads() {
	}

}
