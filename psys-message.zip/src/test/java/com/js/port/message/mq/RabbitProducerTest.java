package com.js.port.message.mq;

import org.apache.commons.lang3.StringUtils;

import com.rabbitmq.client.BuiltinExchangeType;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.MessageProperties;

/**
 * MQ生产者,测试案例
 * 
 * @author gewx
 **/
public final class RabbitProducerTest {

	private static final ConnectionFactory factory = new ConnectionFactory();

	static {
		factory.setUsername("admin");
		factory.setPassword("password");
		factory.setVirtualHost("portzj_pre");
		factory.setHost("192.168.75.135");
	}

	public static void main(String[] args) throws Exception {
		Connection connection = factory.newConnection();
		Channel channel = connection.createChannel();
		channel.exchangeDeclare("PSYS_MESSAGE_EXCHANGE", BuiltinExchangeType.FANOUT, false, false, null);
		String queue = channel.queueDeclare().getQueue();
		channel.queueBind(queue, "PSYS_MESSAGE_EXCHANGE", StringUtils.EMPTY);

		channel.confirmSelect();
		channel.basicPublish("PSYS_MESSAGE_EXCHANGE", StringUtils.EMPTY, MessageProperties.PERSISTENT_TEXT_PLAIN,
				"您的同事,葛伟新上线了~".getBytes());
		if (channel.waitForConfirms()) {
			System.out.println("消息发送成功~");
		}
	}
}
