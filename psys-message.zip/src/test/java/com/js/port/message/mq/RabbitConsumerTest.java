package com.js.port.message.mq;

import java.io.IOException;

import org.apache.commons.lang3.StringUtils;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.DefaultConsumer;
import com.rabbitmq.client.Envelope;
import com.rabbitmq.client.AMQP.BasicProperties;

/**
 * MQ消费者,测试案例
 * 
 * @author gewx
 **/
public final class RabbitConsumerTest {

	private static final ConnectionFactory factory = new ConnectionFactory();

	static {
		factory.setUsername("admin");
		factory.setPassword("password");
		factory.setVirtualHost("portzj_pre");
		factory.setHost("192.168.75.135");
	}

	public static void main(String[] args) throws Exception {
		Connection connection = factory.newConnection();
		Channel channel = connection.createChannel();
		channel.queueDeclare("psysMessage2", true, false, false, null);
		channel.queueBind("psysMessage2", "PSYS_MESSAGE_EXCHANGE", StringUtils.EMPTY);
		channel.basicConsume("psysMessage2", false, "geweixin", new DefaultConsumer(channel) {
			@Override
			public void handleDelivery(String consumerTag, Envelope envelope, BasicProperties properties, byte[] body)
					throws IOException {
				System.out.println("consumerTag: " + consumerTag + ", val: " + new String(body));
				channel.basicAck(envelope.getDeliveryTag(), false);
			}
		});
	}
}
