package com.js.port.message.commons.enums;

import java.util.Optional;
import java.util.stream.Stream;

import lombok.Getter;
import lombok.ToString;

/**
 * 消息渠道枚举
 * 
 * @author gewx
 **/

@Getter
@ToString
public enum MessageChannelEnum {
	
	SMS("SMS", "短信通道"),

	EMAIL("EMAIL", "邮箱通道"),

	WEBCHAT("WEBCHAT", "微信通道"),

	CLOUD("CLOUD", "云平台通道");

	MessageChannelEnum(String code, String comment) {
		this.code = code;
		this.comment = comment;
	}

	/**
	 * 编码
	 **/
	private String code;

	/**
	 * 备注
	 **/
	private String comment;

	/**
	 * 包装消息类型枚举
	 * 
	 * @author gewx
	 * @param messageType 消息类型
	 * @return 枚举类型
	 **/
	public static MessageChannelEnum up(String messageType) {
		Optional<MessageChannelEnum> opt = Stream.of(MessageChannelEnum.values()).filter(val -> val.getCode().equals(messageType))
				.findFirst();
		if (opt.isPresent()) {
			return opt.get();
		} else {
			return null;
		}
	}
}
