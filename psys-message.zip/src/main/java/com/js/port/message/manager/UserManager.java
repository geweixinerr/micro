package com.js.port.message.manager;

import static com.js.port.message.commons.util.StringUtil.getString;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.redis.core.RedisTemplate;

import com.fasterxml.jackson.core.type.TypeReference;
import com.js.port.message.commons.enums.RedisEnum;
import com.js.port.message.commons.log.MicroLogger;
import com.js.port.message.commons.util.JSONUtils;
import com.js.port.message.commons.util.SpringUtils;

import io.netty.channel.Channel;

/**
 * 消息服务器用户会话管理
 * 
 * @author gewx
 **/
public final class UserManager {

	/**
	 * 日志组件
	 **/
	@SuppressWarnings("unused")
	private static final MicroLogger LOGGER = new MicroLogger(UserManager.class);

	/**
	 * 缓存模板类
	 **/
	private static final RedisTemplate<String, String> redisTemplate = SpringUtils.getBean("redisTemplate");

	/**
	 * 新增在线用户
	 * 
	 * @author gewx
	 * @param accNo    账号
	 * @param deptCode 所属部门
	 * @param channel  长连接
	 * @return void
	 **/
	public static void addOnlineUser(Channel channel, String accNo, String deptCode) {
		// 归纳分组,所属部门
		String listDeptStr = getString(
				redisTemplate.opsForHash().get(RedisEnum.REDIS_ONLINE_ACC_DEPT.getCode(), deptCode));
		List<String> listDeptAcc = new ArrayList<>(4);
		if (StringUtils.isNotBlank(listDeptStr)) {
			listDeptAcc = JSONUtils.NON_NULL.toJavaObject(listDeptStr, new TypeReference<List<String>>() {
			});
		}

		if (!listDeptAcc.contains(accNo)) {
			listDeptAcc.add(accNo);
		}

		redisTemplate.opsForHash().put(RedisEnum.REDIS_ONLINE_ACC_DEPT.getCode(), deptCode,
				JSONUtils.NON_NULL.toJSONString(listDeptAcc));

		// bind
		SessionManager.bind(channel, deptCode, accNo);
	}
}
