package com.js.port.message.commons.enums;

import lombok.Getter;

/**
 * 系统版本号枚举
 * 
 * @author gewx
 * **/
@Getter
public enum SystemVersionEnum {

	V1("v1","系统初始化版本");
	
	SystemVersionEnum(String code, String comment) {
		this.code = code;
		this.comment = comment;
	}
	
	/**
	 * 编码
	 * **/
	private String code;
	
	/**
	 * 注释
	 * **/
	private String comment;
}
