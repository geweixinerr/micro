package com.js.port.message;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 散杂货消息平台 
 * 
 * @author gewx 2020.8.20 
 **/

@SpringBootApplication
@MapperScan(basePackages = { "com.js.port.message.dao" })
public class PsysMessageApplication {

	public static void main(String[] args) {
		SpringApplication.run(PsysMessageApplication.class, args);
	}

}
