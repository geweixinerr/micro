package com.js.port.message.template.impl;

import java.util.List;

import com.js.port.message.template.MessageTemplate;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 云平台模板
 * 
 * @author gewx
 **/

@Setter
@Getter
@ToString
public final class CloudMessageTemplate implements MessageTemplate {

	private static final long serialVersionUID = -7710178591846896104L;

	/**
	 * 消息类型
	 **/
	private String msgType;

	/**
	 * 消息标题
	 * **/
	private String title;
	
	/**
	 * 消息内容
	 **/
	private String content;

	/**
	 * 消息状态
	 **/
	private String state;

	/**
	 * 消息路由链接
	 **/
	private String route;

	/**
	 * 消息路由参数
	 **/
	private List<String> routeArg;
	
	/**
	 * 消息备注
	 * **/
	private String remark;
}
