package com.js.port.message.commons.enums;

import lombok.Getter;
import lombok.ToString;

/**
 * 消息类型枚举
 **/
@Getter
@ToString
public enum MsgTypeEnum {

	TIPS_01("01", "纯消息提示");

	MsgTypeEnum(String code, String comment) {
		this.code = code;
		this.comment = comment;
	}

	/**
	 * 编码
	 **/
	private final String code;

	/**
	 * 注释
	 **/
	private final String comment;
}