package com.js.port.message.commons.annotation.valid;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.apache.commons.lang3.StringUtils;

import com.js.port.message.commons.annotation.DateFormat;
import com.js.port.message.commons.util.DateUtils;

/**
 * 注解验证器
 * 
 * @author gewx
 * 
 **/
public class DateFormatValid implements ConstraintValidator<DateFormat, String> {

	private DateFormat date;

	@Override
	public void initialize(DateFormat date) {
		this.date = date;
	}

	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
		if (date.required() && StringUtils.isBlank(value)) {
			return false;
		}
		if (StringUtils.isNotBlank(value)) {
			return DateUtils.validDate(value, date.value());
		}
		return true;
	}
}
