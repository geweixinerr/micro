package com.js.port.message.web.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import com.js.port.message.manager.SessionManager;
import com.js.port.message.manager.SessionManager.ChannelAcc;

/**
 * 心跳检测
 * 
 * @author gewx 2020.3.31
 **/
@Controller
public class HeartbeatController {

	/**
	 * 心跳检测
	 * 
	 * @author gewx
	 * @return 心跳视图
	 **/
	@GetMapping
	public ModelAndView index() {
		ModelAndView view = new ModelAndView("/index");
		return view;
	}

	@GetMapping("/web")
	public ModelAndView websocket() {
		ModelAndView view = new ModelAndView("/websocket");
		return view;
	}

	@GetMapping("/list")
	public void list(HttpServletResponse resp) throws IOException {
		resp.setCharacterEncoding("GBK");
		resp.getWriter().write("在线用户: \n");
		SessionManager.getBindAccChannel().entrySet().forEach(val -> {
			try {
				resp.getWriter().write("账号:  " + val.getKey() + ", channelId: "
						+ val.getValue().getChannel().id().asLongText() + "\n");
			} catch (IOException e) {
			}
		});

		resp.getWriter().write("==================分组=======================" + "\n");
		SessionManager.getBindDeptGroupChannel().entrySet().forEach(val -> {
			try {
				resp.getWriter().write("部门: " + val.getKey() +" \n{\n");
				val.getValue().stream().forEach(v2 -> {
					try {
						ChannelAcc acc = SessionManager.getChannelAccById(v2.id());
						resp.getWriter().write("成员:  " + acc);
					} catch (IOException e) {
					}
				});
				resp.getWriter().write("\n}");
			} catch (IOException e) {
			}
		});
	}
}
