package com.js.port.message.commons.enums;

import lombok.Getter;

/**
 * 消息状态枚举
 **/
@Getter
public enum StateEnum {

	FAIL("FAIL", "错误"),

	SUCCESS("SUCCESS", "成功"),

	WARNING("WARNING", "警告");

	StateEnum(String code, String comment) {
		this.code = code;
		this.comment = comment;
	}

	/**
	 * 编码
	 **/
	private final String code;

	/**
	 * 注释
	 **/
	private final String comment;
}