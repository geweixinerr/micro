package com.js.port.message.bean.dto.login;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.validation.constraints.NotBlank;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 登录用户BO
 * 
 * @author gewx
 **/
@Getter
@Setter
@ToString
public class Account implements Serializable {

	private static final long serialVersionUID = 3637218709693780563L;

	/**
	 * 主键Id
	 **/
	private Long id;

	/**
	 * 账号
	 **/
	@NotBlank(message = "用户名不能为空~")
	private String accNo;

	/**
	 * 用户密码
	 **/
	@NotBlank(message = "密码不能为空~")
	private String accPwd;

	/**
	 * 用户Id
	 **/
	private Long userId;

	/**
	 * 用户编号
	 **/
	private String userNo;

	/**
	 * 用户姓名
	 **/
	private String userName;

	/**
	 * 用户类型
	 **/
	private String userType;

	/**
	 * 所属部门
	 **/
	private String deptCode;

	/**
	 * 所属部门名称
	 **/
	private String deptName;

	/**
	 * 所属岗位
	 **/
	private String deptPost;

	/**
	 * 是否项目组
	 **/
	private String isProject;

	/**
	 * 证件Id
	 **/
	private String card;

	/**
	 * 证件类型
	 **/
	private String cardType;

	/**
	 * 所属公司Id
	 **/
	private Long companyId;

	/**
	 * 所属公司编码
	 **/
	private String companyCode;

	/**
	 * 二级公司编码
	 **/
	private String groupCompanyCode;

	/**
	 * 所属公司名称
	 **/
	private String companyName;

	/**
	 * 二级公司名称
	 **/
	private String groupCompanyName;

	/**
	 * 公司类型,参考枚举CompanyTypeEnum
	 **/
	private String companyType;

	/**
	 * 三级公司列表
	 **/
	private List<Map<String,Object>> companyList;
	
	/**
	 * 登录IP
	 **/
	private String loginIp;

	/**
	 * 登录IP
	 **/
	private String lastLoginIp;

	/**
	 * 登录时间
	 **/
	private Date loginTime;

	/**
	 * 最后登录时间
	 **/
	private Date lastLoginTime;
	/**
	 * 客户公司id
	 */
	private Long customerCompanyId;
}
