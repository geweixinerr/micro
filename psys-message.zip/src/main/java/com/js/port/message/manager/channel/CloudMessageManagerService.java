package com.js.port.message.manager.channel;

import java.util.Arrays;
import java.util.stream.Stream;

import com.js.port.message.commons.log.MicroLogger;
import com.js.port.message.manager.SessionManager;
import com.js.port.message.manager.MessageManagerService;
import com.js.port.message.manager.SessionManager.ChannelAcc;

import io.netty.channel.ChannelId;
import io.netty.channel.group.ChannelGroup;
import io.netty.handler.codec.http.websocketx.TextWebSocketFrame;

/**
 * 消息管理-云平台
 * 
 * @author gewx
 **/
public final class CloudMessageManagerService implements MessageManagerService {

	/**
	 * 日志组件
	 **/
	private static final MicroLogger LOGGER = new MicroLogger(CloudMessageManagerService.class);

	@Override
	public void sendMessageToDept(String message, ChannelId channelId) {
		ChannelGroup group = SessionManager.getChannelGroupById(channelId);
		if (group != null) {
			group.stream().forEach(ctx -> {
				ChannelAcc acc = SessionManager.getChannelAccById(channelId);
				ChannelAcc targetAcc = SessionManager.getChannelAccById(ctx.id());
				if (targetAcc != null && !acc.getAccNo().equals(targetAcc.getAccNo())) {
					ctx.writeAndFlush(new TextWebSocketFrame(message));
				}
			});
		}
	}

	@Override
	public void sendMessageToDept(String message, String accNo) {
		ChannelGroup group = SessionManager.getChannelGroupByAcc(accNo);
		if (group != null) {
			group.stream().forEach(ctx -> {
				ChannelAcc acc = SessionManager.getChannelAccByAcc(accNo);
				ChannelAcc targetAcc = SessionManager.getChannelAccById(ctx.id());
				if (targetAcc != null && !acc.getAccNo().equals(targetAcc.getAccNo())) {
					ctx.writeAndFlush(new TextWebSocketFrame(message));
				}
			});
		}
	}

	@Override
	public void sendMessageToAcc(String message, String... accNo) {
		final String methodName = "sendMessageToAcc";
		LOGGER.enter(methodName, "消息推送, 账号列表:  " + Arrays.asList(accNo));
		Stream.of(accNo).forEach(v1 -> {
			ChannelAcc acc = SessionManager.getChannelAccByAcc(v1);
			LOGGER.info("消息推送,账号缓存主体:  " + acc);
			if (acc != null) {
				acc.getChannel().writeAndFlush(new TextWebSocketFrame(message)).addListener(v2 -> {
					LOGGER.info("消息推送,账号:  " + acc.getAccNo() + ", 推送状态：" + v2.isSuccess());
				});
			}
		});
	}
}
