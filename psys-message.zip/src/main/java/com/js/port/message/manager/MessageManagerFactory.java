package com.js.port.message.manager;

import com.js.port.message.commons.enums.MessageChannelEnum;
import com.js.port.message.manager.impl.CloudMessageManagerImpl;
import com.js.port.message.manager.impl.EmailMessageManagerImpl;
import com.js.port.message.manager.impl.SmsMessageManagerImpl;
import com.js.port.message.manager.impl.WebChatMessageManagerImpl;

/**
 * 消息工厂
 * 
 * @author gewx
 **/
public enum MessageManagerFactory {

	INSTANCE;

	/**
	 * 获取消息对象
	 * 
	 * @author gewx
	 * @param MessageChannelEnum 消息枚举类型
	 * @return 消息对象
	 **/
	public MessageManager getMessageObject(MessageChannelEnum type) {
		switch (type) {
		case CLOUD:
			return new CloudMessageManagerImpl();
		case SMS:
			return new SmsMessageManagerImpl();
		case EMAIL:
			return new EmailMessageManagerImpl();
		case WEBCHAT:
			return new WebChatMessageManagerImpl();
		default:
			return new CloudMessageManagerImpl();
		}
	}
}
