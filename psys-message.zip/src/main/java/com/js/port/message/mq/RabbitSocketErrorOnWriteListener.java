package com.js.port.message.mq;

import java.io.IOException;

import com.js.port.message.commons.log.MicroLogger;
import com.js.port.message.commons.util.StringUtil;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.impl.ErrorOnWriteListener;

/**
 * MQ IO异常处理类
 * 
 * @author gewx
 **/
public class RabbitSocketErrorOnWriteListener implements ErrorOnWriteListener {

	/**
	 * 日志组件
	 **/
	private static final MicroLogger LOGGER = new MicroLogger(RabbitSocketErrorOnWriteListener.class);

	@Override
	public void handle(Connection connection, IOException exception) throws IOException {
		final String methodName = "handle";
		LOGGER.error(methodName, "RabbitMQ网络连接异常,  RabbitIOException: " + StringUtil.getErrorText(exception));
	}
}
