package com.js.port.message.bean.po;

import lombok.ToString;

import com.js.port.message.bean.BaseEntity;

import lombok.Getter;
import lombok.Setter;

/**
 * 短信消息
 * 
 * @author gewx
 **/
@Setter
@Getter
@ToString
public final class SmsMessage extends BaseEntity {

	private static final long serialVersionUID = 2333875401335017624L;

	/**
	 * 消息id
	 **/
	private String id;

	/**
	 * 消息内容
	 **/
	private String content;

	/**
	 * 发送人
	 **/
	private String sender;

	/**
	 * 发送时间
	 **/
	private String sendTime;

	/**
	 * 接收人
	 **/
	private String recipient;

	/**
	 * 接收人手机号
	 **/
	private String recipientMobile;
}
