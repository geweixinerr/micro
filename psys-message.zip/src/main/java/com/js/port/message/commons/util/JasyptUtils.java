package com.js.port.message.commons.util;

import com.js.port.message.commons.annotation.ThreadSafe;
import org.jasypt.encryption.pbe.PooledPBEStringEncryptor;

/**
 * jasypt PBE基于口令加密
 * 
 * @author gewx
 **/
@ThreadSafe 
public final class JasyptUtils {

	/**
	 * salt 随机盐
	 * **/
	private static final String SALT_PASSWORD = "zj_port_2020";

	private static final int CORE_SIZE = Runtime.getRuntime().availableProcessors();

	private static final PooledPBEStringEncryptor ENCRYPTOR = new PooledPBEStringEncryptor();

	// init
	static {
		ENCRYPTOR.setPoolSize(CORE_SIZE);
		ENCRYPTOR.setPassword(SALT_PASSWORD);
		ENCRYPTOR.setAlgorithm("PBEWithMD5AndTripleDES");
	}

	/**
	 * 加密
	 * 
	 * @author gewx
	 * @param val 加密字符串
	 * @return 返回加密后的字符串
	 **/
	public static String encrypt(String val) {
		return ENCRYPTOR.encrypt(val);
	}
	
	/**
	 * 解密
	 * 
	 * @author gewx
	 * @param val 解密字符串
	 * @return 返回解密后的字符串
	 **/
	public static String decrypt(String val) {
		return ENCRYPTOR.decrypt(val);
	}
}
