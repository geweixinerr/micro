package com.js.port.message.web.config;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * 消息推送服务初始化
 * 
 * @author gewx
 **/
@Component
@Order(value = 0)
public class MessageServerComponent implements ApplicationRunner, DisposableBean {

	/**
	 * 销毁对象
	 **/
	private MessageBootstrap.Bootstrap bootstrap;

	/**
	 * 消息服务器端口
	 **/
	@Value("${message.port}")
	private int port;

	/**
	 * 消息服务器Ip
	 **/
	@Value("${message.ip}")
	private String ip;

	@Override
	public void run(ApplicationArguments args) throws Exception {
		bootstrap = MessageBootstrap.start(port, ip);
	}

	@Override
	public void destroy() throws Exception {
		bootstrap.shutdownGracefully();
	}
}
