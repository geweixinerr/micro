package com.js.port.message.template;

import java.io.Serializable;

/**
 * 消息模板标记接口
 * **/
public interface MessageTemplate extends Serializable {

}
