package com.js.port.message.mq;

import org.apache.commons.pool2.ObjectPool;
import org.apache.commons.pool2.PooledObjectFactory;
import org.apache.commons.pool2.impl.GenericObjectPool;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

/**
 * 分布式事务MQ配置初始化
 **/
@Component
@Order(value = 1)
public class RabbitConfiguration implements ApplicationRunner {

	/**
	 * 初始连接数
	 **/
	private static final Integer CPU_CORE = Runtime.getRuntime().availableProcessors();

	/**
	 * RabbitMQ 服务器地址
	 **/
	@Value("${spring.rabbitmq.host}")
	private String host;

	/**
	 * RabbitMQ 服务器端口
	 **/
	@Value("${spring.rabbitmq.port}")
	private int port;

	/**
	 * RabbitMQ 用户名
	 **/
	@Value("${spring.rabbitmq.username}")
	private String username;

	/**
	 * RabbitMQ 密码
	 **/
	@Value("${spring.rabbitmq.password}")
	private String password;

	/**
	 * RabbitMQ 虚拟host
	 **/
	@Value("${spring.rabbitmq.virtual-host}")
	private String virtualHost;

	/**
	 * RabbitMQ 连接超时时间
	 **/
	@Value("${spring.rabbitmq.connection-timeout}")
	private int connectionTimeout;

	/**
	 * 对象池
	 **/
	private ObjectPool<Connection> objectPool;

	/**
	 * 获取对象池
	 * 
	 * @author gewx
	 * @return 对象池
	 **/
	public ObjectPool<Connection> getObjectPool() {
		return this.objectPool;
	}

	@Override
	public void run(ApplicationArguments args) throws Exception {
		ConnectionFactory factory = new ConnectionFactory();
		factory.setUsername(username);
		factory.setPassword(password);
		factory.setHost(host);
		factory.setPort(port);
		factory.setVirtualHost(virtualHost);
		factory.setConnectionTimeout(connectionTimeout);
		factory.setErrorOnWriteListener(new RabbitSocketErrorOnWriteListener());

		GenericObjectPoolConfig<Connection> poolConfig = new GenericObjectPoolConfig<>();
		poolConfig.setMaxTotal(CPU_CORE * 2);
		poolConfig.setMaxIdle(CPU_CORE);
		poolConfig.setMinIdle(CPU_CORE);

		PooledObjectFactory<Connection> poolFactory = new RabbitTcpPoolFactory(factory);
		ObjectPool<Connection> pool = new GenericObjectPool<Connection>(poolFactory, poolConfig);
		for (int i = 0; i < CPU_CORE; i++) {
			pool.addObject();
		}

		this.objectPool = pool;
	}
}
