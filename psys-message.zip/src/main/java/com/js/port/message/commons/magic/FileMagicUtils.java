package com.js.port.message.commons.magic;

import org.apache.commons.lang3.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.js.port.message.commons.annotation.ThreadSafe;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * 文件魔数辅助类
 * 
 * @author gewx
 **/
@ThreadSafe 
public final class FileMagicUtils {

	/**
	 * 根据文件路径获取文件类型
	 * 
	 * @author gewx
	 * @param filePath 文件路径
	 * @throws IOException
	 * @return 文件类型
	 */
	public static String getFileType(String filePath) throws IOException {
		String fileHead = getFileHeader(filePath);
		if (StringUtils.isBlank(fileHead)) {
			return StringUtils.EMPTY;
		}

		return Stream.of(FileType.values()).filter(val -> fileHead.toUpperCase().startsWith(val.getValue()))
				.map(val -> val.getKey()).collect(Collectors.joining());
	}

	/**
	 * 根据字节数组获取文件类型
	 * 
	 * @author gewx
	 * @param byteArray 字节数组
	 * @throws IOException
	 * @return 文件类型
	 */
	public static String getFileType(byte[] byteArray) throws IOException {
		String fileHead = bytes2hex(byteArray);
		if (StringUtils.isBlank(fileHead)) {
			return StringUtils.EMPTY;
		}

		return Stream.of(FileType.values()).filter(val -> fileHead.toUpperCase().startsWith(val.getValue()))
				.map(val -> val.getKey()).collect(Collectors.joining());
	}

	/**
	 * 获取文件头
	 * 
	 * @author gewex
	 * @param filePath 文件路径
	 * @throws IOException
	 * @return 16 进制的文件头信息
	 */
	private static String getFileHeader(String filePath) throws IOException {
		byte[] b = new byte[28];
		try (InputStream inputStream = new FileInputStream(filePath)) {
			inputStream.read(b, 0, 28);
		}
		return bytes2hex(b);
	}

	/**
	 * 将字节数组转换成16进制字符串
	 * 
	 * @author gewx
	 * @param byteArray 字节数组
	 * @return 字符串
	 **/
	private static String bytes2hex(byte[] byteArray) {
		StringBuilder stringBuilder = new StringBuilder();
		for (byte b : byteArray) {
			int v = b & 0xFF;
			String hv = Integer.toHexString(v);
			if (hv.length() < 2) {
				stringBuilder.append(0);
			}
			stringBuilder.append(hv);
		}
		return stringBuilder.toString();
	}
	
	 /**
     * 判断文件大小
     * @author luyy
     * @param :multipartFile:上传的文件
     * @param size: 限制大小
     * @param unit:限制单位（B,K,M,G)
     * @return boolean:是否大于
     */
    public static boolean checkFileSize( MultipartFile multipartFile, int size, String unit) throws IOException {
        long len = multipartFile.getSize();//上传文件的大小, 单位为字节.
        //准备接收换算后文件大小的容器
        double fileSize = 0;
        if ("B".equals(unit.toUpperCase())) {
            fileSize = (double) len;
        } else if ("K".equals(unit.toUpperCase())) {
            fileSize = (double) len / 1024;
        } else if ("M".equals(unit.toUpperCase())) {
            fileSize = (double) len / 1048576;
        } else if ("G".equals(unit.toUpperCase())) {
            fileSize = (double) len / 1073741824;
        }
        //如果上传文件大于限定的容量
        return !(fileSize > size);
    }
}
