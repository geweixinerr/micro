package com.js.port.message.mq.consumer;

import java.io.IOException;
import java.nio.charset.Charset;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.js.port.message.commons.concurrent.ConcurrentLock;
import com.js.port.message.commons.log.MicroLogger;
import com.js.port.message.commons.task.GlobalThreadPoolTaskExecutor;
import com.js.port.message.commons.util.StringUtil;
import com.js.port.message.manager.MessageManagerService;
import com.js.port.message.manager.channel.CloudMessageManagerService;
import com.js.port.message.mq.RabbitConfiguration;
import com.js.port.message.mq.RabbitConnectionContext;
import com.rabbitmq.client.AMQP.BasicProperties;
import com.rabbitmq.client.BuiltinExchangeType;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.DefaultConsumer;
import com.rabbitmq.client.Envelope;

import cn.hutool.core.lang.Snowflake;

/**
 * RabbitMQ 消费者
 * 
 * @author gewx
 **/
@Component
@Order(value = 2)
public class RabbitConsumer implements ApplicationRunner {

	/**
	 * 日志组件
	 **/
	private static final MicroLogger LOGGER = new MicroLogger(RabbitConsumer.class);

	/**
	 * 线程池组件
	 **/
	private static final GlobalThreadPoolTaskExecutor GLOBAL_TASK = GlobalThreadPoolTaskExecutor.getInstance();

	private static final MessageManagerService MESSAGEMANAGER = new CloudMessageManagerService();

	/**
	 * 交换器,广播模式
	 **/
	private static final String QUEUE_EXCHANGE = "PSYS_MESSAGE_EXCHANGE";

	/**
	 * 日志链路追踪
	 **/
	private static final String X_B3_TRACEID = "X-B3-TraceId";

	@Autowired
	private RabbitConfiguration rabbit;

	@Autowired
	private ConcurrentLock lock;

	@Autowired
	private Snowflake snowflake;

	@Override
	public void run(ApplicationArguments args) throws Exception {
		try (RabbitConnectionContext context = new RabbitConnectionContext(rabbit.getObjectPool())) {
			Channel channel = context.getConnection().createChannel();
			channel.basicQos(1024);
			channel.exchangeDeclare(QUEUE_EXCHANGE, BuiltinExchangeType.FANOUT);
			String queue = channel.queueDeclare().getQueue();
			channel.queueBind(queue, QUEUE_EXCHANGE, StringUtils.EMPTY);
			channel.basicConsume(queue, false, new DefaultConsumer(channel) {
				@Override
				public void handleDelivery(String consumerTag, Envelope envelope, BasicProperties properties,
						byte[] body) throws IOException {
					String strJson = new String(body, Charset.forName("utf-8"));
					execute(strJson, () -> {
						try {
							channel.basicAck(envelope.getDeliveryTag(), false);
						} catch (IOException ex) {
							LOGGER.warn("MQ消息确认失败,strJson: " + strJson + ", ex: " + StringUtil.getErrorText(ex));
						}
					});
				}
			});
		}
	}

	/**
	 * 执行任务,幂等处理
	 * 
	 * @author gewx
	 * @param strJson  数据体
	 * @param callBack 回调对象
	 * @return void
	 **/
	private void execute(String strJson, CallBack callBack) {
		final String methodName = "execute";
		LOGGER.enter(methodName, "MQ消费业务执行[start], " + strJson);

		GLOBAL_TASK.submitListenable(() -> {
			try {
//				MDC.put(X_B3_TRACEID, message.getTraceId());
				/*
				 * lock.key(message.getGtld()).timeOut(10).run(() -> {
				 * 
				 * });
				 */

				MESSAGEMANAGER.sendMessageToAcc("您好，葛伟新上线啦", "gewx");
			} finally {
				MDC.remove(X_B3_TRACEID);
				callBack.invoke();
			}
		});
	}

	/**
	 * 内部回调接口
	 * 
	 * @author gewx
	 **/
	interface CallBack {

		/**
		 * 回调方法
		 * 
		 * @author gewx
		 * @return void
		 **/
		void invoke();
	}
}
