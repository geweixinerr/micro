package com.js.port.message.mq.consumer;

import java.io.IOException;
import java.nio.charset.Charset;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.js.port.message.bean.dto.mq.Message;
import com.js.port.message.commons.enums.MessageChannelEnum;
import com.js.port.message.commons.enums.ReceiveTargetEnum;
import com.js.port.message.commons.log.MicroLogger;
import com.js.port.message.commons.task.GlobalThreadPoolTaskExecutor;
import com.js.port.message.commons.util.JSONUtils;
import com.js.port.message.commons.util.StringUtil;
import com.js.port.message.manager.MessageManager;
import com.js.port.message.manager.MessageManagerFactory;
import com.js.port.message.mq.RabbitConfiguration;
import com.js.port.message.mq.RabbitConnectionContext;
import com.rabbitmq.client.AMQP.BasicProperties;
import com.rabbitmq.client.BuiltinExchangeType;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.DefaultConsumer;
import com.rabbitmq.client.Envelope;

/**
 * 分布式消息组件
 * 
 * @author gewx
 **/
@Component
@Order(value = 2)
public class RabbitConsumer implements ApplicationRunner {

	/**
	 * 日志组件
	 **/
	private static final MicroLogger LOGGER = new MicroLogger(RabbitConsumer.class);

	/**
	 * 线程池组件
	 **/
	private static final GlobalThreadPoolTaskExecutor GLOBAL_TASK = GlobalThreadPoolTaskExecutor.getInstance();

	/**
	 * 交换器,广播模式
	 **/
	private static final String QUEUE_EXCHANGE = "PSYS_MESSAGE_EXCHANGE";

	/**
	 * 日志链路追踪
	 **/
	private static final String X_B3_TRACEID = "X-B3-TraceId";

	@Autowired
	private RabbitConfiguration rabbit;

	@Override
	public void run(ApplicationArguments args) throws Exception {
		try (RabbitConnectionContext context = new RabbitConnectionContext(rabbit.getObjectPool())) {
			Channel channel = context.getConnection().createChannel();
			channel.basicQos(1024);
			channel.exchangeDeclare(QUEUE_EXCHANGE, BuiltinExchangeType.FANOUT);
			String queue = channel.queueDeclare().getQueue();
			channel.queueBind(queue, QUEUE_EXCHANGE, StringUtils.EMPTY);
			channel.basicConsume(queue, false, new DefaultConsumer(channel) {
				@Override
				public void handleDelivery(String consumerTag, Envelope envelope, BasicProperties properties,
						byte[] body) throws IOException {
					String strJson = new String(body, Charset.forName("utf-8"));
					execute(strJson, () -> {
						try {
							channel.basicAck(envelope.getDeliveryTag(), false);
						} catch (IOException ex) {
							LOGGER.warn("消息推送确认失败,strJson: " + strJson + ", ex: " + StringUtil.getErrorText(ex));
						}
					});
				}
			});
		}
	}

	/**
	 * 执行任务,幂等处理
	 * 
	 * @author gewx
	 * @param strJson  数据体
	 * @param callBack 回调对象
	 * @return void
	 **/
	private void execute(String strJson, CallBack callBack) {
		final String methodName = "execute";
		LOGGER.enter(methodName, "消息推送[start], " + strJson);

		GLOBAL_TASK.submitListenable(() -> {
			try {
				Message message = JSONUtils.NON_NULL.toJavaObject(strJson, Message.class);
				MDC.put(X_B3_TRACEID, message.getTraceId());

				LOGGER.info(methodName, "消息推送开始---> " + message);

				MessageManager messageObject = MessageManagerFactory.INSTANCE
						.getMessageObject(MessageChannelEnum.up(message.getChannel()));
				messageObject.insert(message);
				if (ReceiveTargetEnum.PERSONAL.getCode().equals(message.getTarget())) {
					LOGGER.info(methodName, "推送个人消息~");
					messageObject.sendMessageToAcc(JSONUtils.NON_NULL.toJSONString(message.getTemplate()),
							message.getReceiveAccNo().toArray(new String[] {}));
				} else {
					LOGGER.info(methodName, "推送部门消息~");
					messageObject.sendMessageToDept(JSONUtils.NON_NULL.toJSONString(message.getTemplate()),
							message.getReceiveAccNo().get(0));
				}
			} finally {
				MDC.remove(X_B3_TRACEID);
				callBack.invoke();
			}
		});
	}

	/**
	 * 内部回调接口
	 * 
	 * @author gewx
	 **/
	interface CallBack {

		/**
		 * 回调方法
		 * 
		 * @author gewx
		 * @return void
		 **/
		void invoke();
	}
}
