package com.js.port.message.manager.impl;

import static org.apache.commons.collections4.ListUtils.emptyIfNull;

import java.util.Arrays;
import java.util.Date;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.slf4j.MDC;

import com.js.port.message.bean.dto.mq.Message;
import com.js.port.message.bean.po.MCloudMessage;
import com.js.port.message.commons.concurrent.ConcurrentLock;
import com.js.port.message.commons.log.MicroLogger;
import com.js.port.message.commons.util.DateUtils;
import com.js.port.message.commons.util.JSONUtils;
import com.js.port.message.commons.util.SpringUtils;
import com.js.port.message.dao.cloud.CloudMessageDao;
import com.js.port.message.manager.SessionManager;
import com.js.port.message.manager.MessageManager;
import com.js.port.message.manager.SessionManager.ChannelAcc;
import com.js.port.message.template.impl.CloudMessageTemplate;

import io.netty.channel.Channel;
import io.netty.channel.group.ChannelGroup;
import io.netty.handler.codec.http.websocketx.TextWebSocketFrame;

/**
 * 消息管理-云平台
 * 
 * @author gewx
 **/
public final class CloudMessageManagerImpl implements MessageManager {

	/**
	 * 日志组件
	 **/
	private static final MicroLogger LOGGER = new MicroLogger(CloudMessageManagerImpl.class);

	/**
	 * 日志链路追踪
	 **/
	private static final String X_B3_TRACEID = "X-B3-TraceId";

	/**
	 * 云平台消息Dao
	 **/
	private final CloudMessageDao cloudDao = SpringUtils.getBean(CloudMessageDao.class);

	/**
	 * 并发锁
	 **/
	private final ConcurrentLock lock = SpringUtils.getBean(ConcurrentLock.class);

	@Override
	public void sendMessageToDept(String message, Channel channel) {
		ChannelGroup group = SessionManager.getChannelGroupById(channel.id());
		if (group != null) {
			group.remove(channel);
			group.stream().forEach(ctx -> {
				ctx.writeAndFlush(new TextWebSocketFrame(message));
			});
		}
	}

	@Override
	public void sendMessageToDept(String message, String accNo) {
		ChannelGroup group = SessionManager.getChannelGroupByAcc(accNo);
		ChannelAcc acc = SessionManager.getChannelAccByAcc(accNo);
		if (group != null && acc != null) {
			group.remove(acc.getChannel());
			group.stream().forEach(ctx -> {
				ctx.writeAndFlush(new TextWebSocketFrame(message));
			});
		}
	}

	@Override
	public void sendMessageToAcc(String message, String... accNo) {
		final String methodName = "sendMessageToAcc";
		LOGGER.enter(methodName, "消息推送, 账号列表:  " + Arrays.asList(accNo));
		Stream.of(accNo).forEach(v1 -> {
			ChannelAcc acc = SessionManager.getChannelAccByAcc(v1);
			LOGGER.info("消息推送,账号缓存主体:  " + acc);
			if (acc != null && acc.getChannel().isActive()) {
				String traceId = MDC.get(X_B3_TRACEID);
				acc.getChannel().writeAndFlush(new TextWebSocketFrame(message)).addListener(v2 -> {
					MDC.put(X_B3_TRACEID, traceId);
					LOGGER.info("消息推送,账号:  " + acc.getAccNo() + ", 推送状态：" + v2.isSuccess());
				});
			}
		});
	}

	@Override
	public void insert(Message message) {
		try {
			lock.key(String.valueOf(message.getId())).timeOut(5).run(() -> {
				CloudMessageTemplate template = JSONUtils.NON_NULL.toJavaObject(
						JSONUtils.NON_NULL.toJSONString(message.getTemplate()), CloudMessageTemplate.class);
				MCloudMessage cloudMessage = new MCloudMessage();
				cloudMessage.setId(message.getId());
				cloudMessage.setMsgType(template.getMsgType());
				cloudMessage.setTitle(template.getTitle());
				cloudMessage.setContent(template.getContent());
				cloudMessage.setState(template.getState());
				cloudMessage.setRoute(template.getRoute());
				cloudMessage.setRouteArg(emptyIfNull(template.getRouteArg()).stream().collect(Collectors.joining(",")));
				cloudMessage.setSendAccno(message.getSendAccno());
				cloudMessage.setSendTime(DateUtils.parseDate(message.getSendTime(), "yyyy-MM-dd HH:mm:ss"));
				cloudMessage.setReceiveAccno(
						emptyIfNull(message.getReceiveAccNo()).stream().collect(Collectors.joining(",")));
				cloudMessage.setReceiveTime(new Date());
				cloudMessage.setReceiveOrgCode(message.getReceiveOrgCode());
				cloudMessage.setReceiveTarget(message.getTarget());
				cloudMessage.setRemark(template.getRemark());

				cloudDao.insert(cloudMessage);
			});
		} catch (Exception ex) {
			// 基于MQ广播模式, 这里异常不做处理
		}
	}
}
