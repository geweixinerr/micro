package com.js.port.message.commons.enums;

import lombok.Getter;

/**
 * 消息接收目标枚举
 * 
 * @author gewx
 **/

@Getter
public enum ReceiveTargetEnum {

	/**
	 * 个人
	 **/
	PERSONAL("01", "个人用户"),

	/**
	 * 部门
	 **/
	ORG_DEPT("02", "群发部门");

	ReceiveTargetEnum(String code, String comment) {
		this.code = code;
		this.comment = comment;
	}

	/**
	 * 编码
	 **/
	private String code;

	/**
	 * 注释
	 **/
	private String comment;
}
