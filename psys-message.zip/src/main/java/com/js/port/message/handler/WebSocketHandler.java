package com.js.port.message.handler;

import static com.js.port.message.commons.util.StringUtil.*;

import com.js.port.message.commons.jwt.Jwt;
import com.js.port.message.commons.util.JwtUtils;
import com.js.port.message.manager.MessageManagerService;
import com.js.port.message.manager.SessionManager;
import com.js.port.message.manager.UserManager;
import com.js.port.message.manager.channel.MessageManagerServiceFactory;
import com.js.port.message.manager.channel.MessageManagerServiceFactory.MessageType;

import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.handler.codec.http.websocketx.TextWebSocketFrame;
import io.netty.handler.codec.http.websocketx.WebSocketServerProtocolHandler;

/**
 * WebSocket数据处理类
 * 
 * @author gewx
 **/
public class WebSocketHandler extends SimpleChannelInboundHandler<TextWebSocketFrame> {

	/**
	 * 用户所属部门
	 **/
	private static final String ACC_DEPT = "deptCode";

	@Override
	protected void channelRead0(ChannelHandlerContext ctx, TextWebSocketFrame msg) throws Exception {
		Jwt.JwtBean bean = JwtUtils.parseToken(msg.text());
		UserManager.addOnlineUser(ctx.channel(), bean.getAccNo(), getString(bean.getKv().get(ACC_DEPT)));

		MessageManagerService messageObject = MessageManagerServiceFactory.INSTANCE.getMessageObject(MessageType.CLOUD);
		messageObject.sendMessageToDept("您好,您的同事" + bean.getUserName() + "上线啦~", ctx.channel().id());
	}

	@Override
	public void channelInactive(ChannelHandlerContext ctx) throws Exception {
		SessionManager.removeById(ctx.channel().id());
	}

	@Override
	public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
		SessionManager.removeById(ctx.channel().id());
		ctx.close();
	}

	@Override
	public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {
		if (evt instanceof WebSocketServerProtocolHandler.HandshakeComplete) {
			// 登录提示tips
			ctx.writeAndFlush(new TextWebSocketFrame("今天也是元气满满的一天喔~"));
		} else {
			super.userEventTriggered(ctx, evt);
		}
	}
}