package com.js.port.message.handler;

import static com.js.port.message.commons.util.StringUtil.getString;

import com.js.port.message.commons.enums.MessageChannelEnum;
import com.js.port.message.commons.enums.MsgTypeEnum;
import com.js.port.message.commons.enums.StateEnum;
import com.js.port.message.commons.jwt.Jwt;
import com.js.port.message.commons.util.JSONUtils;
import com.js.port.message.commons.util.JwtUtils;
import com.js.port.message.manager.MessageManager;
import com.js.port.message.manager.MessageManagerFactory;
import com.js.port.message.manager.SessionManager;
import com.js.port.message.manager.UserManager;
import com.js.port.message.template.impl.CloudMessageTemplate;

import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.handler.codec.http.websocketx.TextWebSocketFrame;
import io.netty.handler.codec.http.websocketx.WebSocketServerProtocolHandler;

/**
 * WebSocket数据处理类
 * 
 * @author gewx
 **/
public class WebSocketHandler extends SimpleChannelInboundHandler<TextWebSocketFrame> {

	/**
	 * 用户所属部门
	 **/
	private static final String ACC_DEPT = "deptCode";

	@Override
	protected void channelRead0(ChannelHandlerContext ctx, TextWebSocketFrame msg) throws Exception {
		Jwt.JwtBean bean = JwtUtils.parseToken(msg.text());
		UserManager.addOnlineUser(ctx.channel(), bean.getAccNo(), getString(bean.getKv().get(ACC_DEPT)));

		MessageManager messageObject = MessageManagerFactory.INSTANCE.getMessageObject(MessageChannelEnum.CLOUD);

		CloudMessageTemplate template = new CloudMessageTemplate();
		template.setTitle("建联成功");
		template.setContent("您好,您的同事" + bean.getUserName() + "上线啦~");
		template.setMsgType(MsgTypeEnum.TIPS_01.getCode());
		template.setState(StateEnum.SUCCESS.getCode());

		messageObject.sendMessageToDept(JSONUtils.NON_NULL.toJSONString(template), ctx.channel());
	}

	@Override
	public void channelInactive(ChannelHandlerContext ctx) throws Exception {
		SessionManager.removeById(ctx.channel().id());
	}

	@Override
	public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
		SessionManager.removeById(ctx.channel().id());
		ctx.close();
	}

	@Override
	public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {
		if (evt instanceof WebSocketServerProtocolHandler.HandshakeComplete) {
			// 登录提示tips
			CloudMessageTemplate template = new CloudMessageTemplate();
			template.setTitle("建联成功");
			template.setContent("今天也是元气满满的一天喔~");
			template.setMsgType(MsgTypeEnum.TIPS_01.getCode());
			template.setState(StateEnum.SUCCESS.getCode());
			ctx.writeAndFlush(new TextWebSocketFrame(JSONUtils.NON_NULL.toJSONString(template)));
		} else {
			super.userEventTriggered(ctx, evt);
		}
	}
}