package com.js.port.message.task;

import java.util.Map;
import java.util.Set;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.js.port.message.commons.enums.RedisEnum;
import com.js.port.message.commons.log.MicroLogger;
import com.js.port.message.manager.SessionManager;
import com.js.port.message.manager.SessionManager.ChannelAcc;

import io.netty.handler.codec.http.websocketx.PingWebSocketFrame;

/**
 * 定时清理超时客户端连接
 * 
 * @author gewx
 */
@Component
@EnableScheduling
public class ScheduleTask {

	/**
	 * 日志组件
	 **/
	private static final MicroLogger LOGGER = new MicroLogger(ScheduleTask.class);

	@Autowired
	private RedisTemplate<String, String> redisTemplate;

	/**
	 * 5分钟清理过期用户
	 * 
	 * @author gewx
	 **/
	@Scheduled(cron = "0 0/5 * * * ?")
	public void removeExpireUser() {
		final String methodName = "removeExpireUser";
		LOGGER.enter(methodName, "消息组件定时清理过期用户");
		
		Map<String, ChannelAcc> bindAccMap = SessionManager.getBindAccChannel();
		long currentTime = System.currentTimeMillis();
		long start = currentTime - 3600 * 1000;
		Set<String> onlineList = redisTemplate.opsForZSet().rangeByScore(RedisEnum.PSYS_MASTER_LOGIN_ACCOUNT.getCode(),
				start, currentTime);
		if (CollectionUtils.isNotEmpty(onlineList)) {
			bindAccMap.entrySet().forEach(v1 -> {
				if (!onlineList.contains(v1.getValue().getAccNo())) {
					SessionManager.removeByAcc(v1.getKey());
					SessionManager.getBindDeptGroupChannel().entrySet().stream()
							.filter(v2 -> v2.getKey().equals(v1.getValue().getDeptCode())).forEach(v2 -> {
								v2.getValue().remove(v1.getValue().getChannel());
							});
				}
			});
		}
	}

	/**
	 * 心跳检测,45秒一次
	 * 
	 * @author gewx
	 **/
	@Scheduled(cron = "*/45 * * * * ?")
	public void heartbeat() {
		final String methodName = "heartbeat";
		LOGGER.enter(methodName, "心跳检测");

		SessionManager.getBindDeptGroupChannel().entrySet().forEach(v1 -> {
			v1.getValue().forEach(v2 -> {
				v2.writeAndFlush(new PingWebSocketFrame()).addListener(v3 -> {
					if (!v3.isSuccess()) {
						v1.getValue().remove(v2);
					}
				});
			});
		});
	}
}
