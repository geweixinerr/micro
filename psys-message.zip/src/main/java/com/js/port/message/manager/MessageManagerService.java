package com.js.port.message.manager;

import io.netty.channel.ChannelId;

/**
 * 消息服务定义
 **/
public interface MessageManagerService {

	/**
	 * 部门群发消息
	 * 
	 * @author gewx
	 * @param message   消息
	 * @param channelId 客户端Id
	 * @return void
	 **/
	public void sendMessageToDept(String message, ChannelId channelId);

	/**
	 * 部门群发消息
	 * 
	 * @author gewx
	 * @param message 消息
	 * @param accNo   账号
	 * @return void
	 **/
	public void sendMessageToDept(String message, String accNo);

	/**
	 * 单个或者多个推送消息
	 * 
	 * @author gewx
	 * @param message 消息
	 * @param accNo   账号列表
	 * @return void
	 **/
	public void sendMessageToAcc(String message, String... accNo);
}
