package com.js.port.message.bean.dto.mq;

import java.io.Serializable;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 消息
 * 
 * @author gewx
 **/

@Getter
@Setter
@ToString
public class Message implements Serializable {

	private static final long serialVersionUID = -1387315553769313253L;

	/**
	 * 消息Id
	 **/
	private Long id;

	/**
	 * 日志追踪traceId
	 **/
	private String traceId;

	/**
	 * 消息通道
	 **/
	private String channel;
	
	/**
	 * 发送人
	 **/
	private String sendAccno;
	
	/**
	 * 发送时间
	 * **/
	private String sendTime;
	
	/**
	 * 账号列表
	 **/
	private List<String> receiveAccNo;

	/**
	 * 接收组织编码
	 * **/
	private String receiveOrgCode;
	
	/**
	 * 接收组织名称
	 * **/
	private String receiveOrgName;
	
	/**
	 * 目标: 个人/组织部门
	 **/
	private String target;
	
	/**
	 * 消息主体
	 **/
	private Object template;
	
}
