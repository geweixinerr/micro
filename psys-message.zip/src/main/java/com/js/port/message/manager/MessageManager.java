package com.js.port.message.manager;

import com.js.port.message.bean.dto.mq.Message;

import io.netty.channel.Channel;

/**
 * 消息服务定义
 **/
public interface MessageManager {

	/**
	 * 部门群发消息
	 * 
	 * @author gewx
	 * @param message   消息
	 * @param channel 客户端
	 * @return void
	 **/
	void sendMessageToDept(String message, Channel channel);

	/**
	 * 部门群发消息
	 * 
	 * @author gewx
	 * @param message 消息
	 * @param accNo   账号
	 * @return void
	 **/
	void sendMessageToDept(String message, String accNo);

	/**
	 * 单个或者多个推送消息
	 * 
	 * @author gewx
	 * @param message 消息
	 * @param accNo   账号列表
	 * @return void
	 **/
	void sendMessageToAcc(String message, String... accNo);
	
	/**
	 * 消息存储
	 * 
	 * @author gewx
	 * @param  message 消息主体
	 * @return void
	 **/
	void insert(Message message);
}
