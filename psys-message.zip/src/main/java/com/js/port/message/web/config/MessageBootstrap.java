package com.js.port.message.web.config;

import java.net.InetSocketAddress;

import org.apache.commons.lang3.SystemUtils;

import com.js.port.message.commons.annotation.ThreadSafe;
import com.js.port.message.commons.log.MicroLogger;
import com.js.port.message.commons.util.StringUtil;
import com.js.port.message.handler.WebSocketHandler;

import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.epoll.EpollEventLoopGroup;
import io.netty.channel.epoll.EpollServerSocketChannel;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.codec.http.HttpObjectAggregator;
import io.netty.handler.codec.http.HttpServerCodec;
import io.netty.handler.codec.http.websocketx.WebSocketServerProtocolHandler;
import io.netty.handler.stream.ChunkedWriteHandler;

/**
 * 消息服务器
 * 
 * @author gewx
 **/
@ThreadSafe
public final class MessageBootstrap {

	private static final int CPU_NUM = Runtime.getRuntime().availableProcessors();

	private static final MicroLogger LOGGER = new MicroLogger(MessageBootstrap.class);

	private MessageBootstrap() {
	}

	/**
	 * 服务启动
	 * 
	 * @author gewx
	 * @param port 端口
	 * @param ip   绑定本地ip
	 * @throws InterruptedException
	 * @return 内置启动器对象
	 **/
	public static Bootstrap start(int port, String ip) throws InterruptedException {
		ServerBootstrap server = new ServerBootstrap();
		EventLoopGroup acceptGroup = SystemUtils.IS_OS_LINUX ? new EpollEventLoopGroup(1) : new NioEventLoopGroup(1);
		EventLoopGroup ioGroup = SystemUtils.IS_OS_LINUX ? new EpollEventLoopGroup(CPU_NUM * 2)
				: new NioEventLoopGroup(CPU_NUM * 2);
		server.group(acceptGroup, ioGroup)
				.channel(SystemUtils.IS_OS_LINUX ? EpollServerSocketChannel.class : NioServerSocketChannel.class);

		InetSocketAddress localAddress = new InetSocketAddress(ip, port);

		server.option(ChannelOption.SO_BACKLOG, 8192).localAddress(localAddress)
				.childHandler(new ChannelInitializer<SocketChannel>() {
					@Override
					protected void initChannel(SocketChannel ch) throws Exception {
						ChannelPipeline pipline = ch.pipeline();
						pipline.addLast(new HttpServerCodec());
						pipline.addLast(new ChunkedWriteHandler());
						pipline.addLast(new HttpObjectAggregator(8192));
						pipline.addLast(new WebSocketServerProtocolHandler("/ws"));
						pipline.addLast(new WebSocketHandler());
					}
				});

		server.bind().sync().addListener(new ChannelFutureListener() {
			@Override
			public void operationComplete(ChannelFuture future) throws Exception {
				if (future.isSuccess()) {
					LOGGER.info("消息组件启动成功~");
				} else {
					String message = StringUtil.getErrorText(future.cause());
					LOGGER.warn("消息组件服务启动失败, ex: " + message);
				}
			}
		});

		return () -> {
			LOGGER.info("消息组件优雅关机,释放资源...");
			acceptGroup.shutdownGracefully();
			ioGroup.shutdownGracefully();
		};
	}

	/**
	 * 函数式服务,优雅关机
	 * 
	 * @author gewx
	 **/
	@FunctionalInterface
	interface Bootstrap {
		void shutdownGracefully();
	}
}
