package com.js.port.message.template.impl;

import com.js.port.message.template.MessageTemplate;

/**
 * 邮箱消息模板
 * 
 * @author gewx
 * **/
public final class EmailTemplate implements MessageTemplate {

	private static final long serialVersionUID = 133689170756204758L;

}
