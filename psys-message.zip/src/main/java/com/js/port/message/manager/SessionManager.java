package com.js.port.message.manager;

import java.util.Collections;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import io.netty.channel.Channel;
import io.netty.channel.ChannelId;
import io.netty.channel.group.ChannelGroup;
import io.netty.channel.group.DefaultChannelGroup;
import io.netty.util.concurrent.GlobalEventExecutor;
import lombok.Getter;

/**
 * channel分组用户会话管理
 * 
 * @author gewx
 **/
public final class SessionManager {

	/**
	 * 部门与ChannelGroup绑定关系
	 **/
	private static final Map<String, ChannelGroup> ACC_CHANNEL_GROUP = new ConcurrentHashMap<>(512);

	/**
	 * 用户与Channel绑定关系列表
	 **/
	private static final Map<String, ChannelAcc> ACC_CHANNEL = new ConcurrentHashMap<>(512);

	/**
	 * 新增channel与用户绑定关系
	 * 
	 * @author gewx
	 * @param channel  长连接对象
	 * @param deptCode 部门编码
	 * @param accNo    账号
	 * @return void
	 **/
	public static void bind(Channel channel, String deptCode, String accNo) {
		removeByAcc(accNo);
		ChannelAcc channelAcc = new ChannelAcc(accNo, deptCode, channel);
		ACC_CHANNEL.put(accNo, channelAcc);
		ACC_CHANNEL.put(channel.id().asLongText(), channelAcc);

		synchronized (SessionManager.class) {
			if (!ACC_CHANNEL_GROUP.containsKey(deptCode)) {
				ChannelGroup group = new DefaultChannelGroup(deptCode, GlobalEventExecutor.INSTANCE);
				group.add(channel);
				ACC_CHANNEL_GROUP.put(deptCode, group);
			} else {
				ACC_CHANNEL_GROUP.get(deptCode).add(channel);
			}
		}
	}

	/**
	 * 获取所属部门所有channel列表
	 * 
	 * @author gewx
	 * @param channelId channelId
	 * @return channel组
	 **/
	public static ChannelGroup getChannelGroupById(ChannelId channelId) {
		ChannelAcc acc = ACC_CHANNEL.get(channelId.asLongText());
		if (acc != null) {
			return ACC_CHANNEL_GROUP.get(acc.getDeptCode());
		} else {
			return null;
		}
	}

	/**
	 * 获取所属部门所有channel列表
	 * 
	 * @author gewx
	 * @param accNo 账号
	 * @return channel组
	 **/
	public static ChannelGroup getChannelGroupByAcc(String accNo) {
		ChannelAcc acc = ACC_CHANNEL.get(accNo);
		if (acc != null) {
			return ACC_CHANNEL_GROUP.get(acc.getDeptCode());
		} else {
			return null;
		}
	}

	/**
	 * 清理用户在线状态
	 * 
	 * @author gewx
	 * 
	 * @param accNo 账号
	 * @return void
	 **/
	public static void removeByAcc(String accNo) {
		ChannelAcc acc = ACC_CHANNEL.get(accNo);
		if (acc != null) {
			ACC_CHANNEL.remove(acc.getAccNo());
			ACC_CHANNEL.remove(acc.getChannel().id().asLongText());
			acc.getChannel().close();
		}
	}

	/**
	 * 清理用户在线状态
	 * 
	 * @author gewx
	 * @param channelId
	 * @return void
	 **/
	public static void removeById(ChannelId channelId) {
		ChannelAcc acc = ACC_CHANNEL.get(channelId.asLongText());
		if (acc != null) {
			ACC_CHANNEL.remove(acc.getAccNo());
			ACC_CHANNEL.remove(acc.getChannel().id().asLongText());
		}
	}

	/**
	 * 获取ChannelAcc绑定对象
	 * 
	 * @author gewx
	 * @param channelId
	 * @return ChannelAcc
	 **/
	public static ChannelAcc getChannelAccById(ChannelId channelId) {
		return ACC_CHANNEL.get(channelId.asLongText());
	}

	/**
	 * 获取ChannelAcc绑定对象
	 * 
	 * @author gewx
	 * @param accNo 账号
	 * @return ChannelAcc
	 **/
	public static ChannelAcc getChannelAccByAcc(String accNo) {
		return ACC_CHANNEL.get(accNo);
	}

	/**
	 * 获取账号/连接关联列表
	 * 
	 * @author gewx
	 * @return 只读绑定数据
	 **/
	public static Map<String, ChannelAcc> getBindAccChannel() {
		return Collections.unmodifiableMap(ACC_CHANNEL);
	}

	/**
	 * 获取部门/连接分组关联列表
	 * 
	 * @author gewx
	 * @return 只读绑定数据
	 **/
	public static Map<String, ChannelGroup> getBindDeptGroupChannel() {
		return Collections.unmodifiableMap(ACC_CHANNEL_GROUP);
	}

	@Getter
	public static class ChannelAcc {

		private final String accNo;

		private final String deptCode;

		private final Channel channel;

		public ChannelAcc(String accNo, String deptCode, Channel channel) {
			this.accNo = accNo;
			this.deptCode = deptCode;
			this.channel = channel;
		}

		@Override
		public String toString() {
			ToStringBuilder builder = new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE);
			builder.append("accNo", this.accNo);
			builder.append("deptCode", this.deptCode);
			builder.append("channelId", this.channel.id().asLongText());
			builder.append("channel", this.channel);
			return builder.build();
		}
	}
}
