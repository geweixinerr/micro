package com.js.port.message.manager.channel;

import com.js.port.message.manager.MessageManagerService;

import io.netty.channel.ChannelId;

/**
 * 消息管理-邮箱平台
 * 
 * @author gewx
 **/
public class EmailMessageManagerService implements MessageManagerService {

	@Override
	public void sendMessageToDept(String message, ChannelId channelId) {
		// TODO Auto-generated method stub

	}

	@Override
	public void sendMessageToDept(String message, String accNo) {
		// TODO Auto-generated method stub

	}

	@Override
	public void sendMessageToAcc(String message, String... accNo) {
		// TODO Auto-generated method stub

	}

}
