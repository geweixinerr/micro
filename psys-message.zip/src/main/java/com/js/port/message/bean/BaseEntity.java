package com.js.port.message.bean;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.Date;

/**
 * 基础bean
 * 
 * @author gewx
 **/
@Setter
@Getter
@EqualsAndHashCode
public class BaseEntity  implements Serializable {

	private static final long serialVersionUID = -6734686200034099011L;

	/**
	 * 录入人
	 */
	private String createBy;

	/**
	 * 录入人姓名
	 */
	private String createName;

	/**
	 * 录入时间
	 */
	private Date createTime;

	/**
	 * 更新者
	 */
	private String updateBy;

	/**
	 * 更新者姓名
	 */
	private String updateName;

	/**
	 * 更新时间
	 */
	private Date updateTime;
}
