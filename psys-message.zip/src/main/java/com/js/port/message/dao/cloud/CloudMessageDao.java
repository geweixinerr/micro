package com.js.port.message.dao.cloud;

import com.js.port.message.bean.po.MCloudMessage;

/**
 * 消息云->平台消息Dao
 **/
public interface CloudMessageDao {

	/**
	 * 平台消息保存
	 * 
	 * @author gewx
	 * @param mcloudMessage 云消息
	 * @return 受影响行数
	 **/
	int insert(MCloudMessage mcloudMessage);
}
