package com.js.port.message.template.impl;

import com.js.port.message.template.MessageTemplate;

/**
 * 云平台模板
 * 
 * @author gewx
 * **/
public final class CloudTemplate implements MessageTemplate {

	private static final long serialVersionUID = -7710178591846896104L;

}
