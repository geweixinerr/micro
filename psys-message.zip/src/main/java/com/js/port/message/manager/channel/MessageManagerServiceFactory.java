package com.js.port.message.manager.channel;

import com.js.port.message.manager.MessageManagerService;

import lombok.Getter;

/**
 * 消息工厂
 * 
 * @author gewx
 **/
public enum MessageManagerServiceFactory {

	INSTANCE;

	public String msg;

	/**
	 * 消息枚举
	 **/
	@Getter
	public enum MessageType {

		SMS("SMS", "短信通道"),

		EMAIL("email", "邮箱通道"),

		WEBCHAT("webChat", "微信通道"),

		CLOUD("cloud", "云平台通道");

		MessageType(String code, String comment) {
			this.code = code;
			this.comment = comment;
		}

		/**
		 * 编码
		 **/
		private String code;

		/**
		 * 备注
		 **/
		private String comment;

	}

	/**
	 * 获取消息对象
	 * 
	 * @author gewx
	 * @param MessageType 消息枚举类型
	 * @return 消息对象
	 **/
	public MessageManagerService getMessageObject(MessageType type) {
		switch (type) {
		case CLOUD:
			return new CloudMessageManagerService();
		case SMS:
			return new SmsMessageManagerService();
		case EMAIL:
			return new EmailMessageManagerService();
		case WEBCHAT:
			return new WebChatMessageManagerService();
		default:
			return new CloudMessageManagerService();
		}
	}
}
