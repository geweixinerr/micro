package com.js.port.message.mq;

import org.apache.commons.pool2.ObjectPool;

import com.rabbitmq.client.Connection;

/**
 * Rabbit 连接上下文
 **/
public class RabbitConnectionContext implements AutoCloseable {

	/**
	 * 线程上下文
	 **/
	private static final ThreadLocal<Connection> CONNECTION = new ThreadLocal<>();

	/**
	 * Rabbit Connection 连接池对象
	 **/
	private final ObjectPool<Connection> objectPool;

	public RabbitConnectionContext(ObjectPool<Connection> objectPool) {
		this.objectPool = objectPool;
	}

	/**
	 * 获取新连接
	 * 
	 * @author gewx
	 * @return tcp连接对象
	 **/
	public Connection getConnection() throws Exception {
		Connection connection = objectPool.borrowObject();
		CONNECTION.set(connection);
		return connection;
	}

	@Override
	public void close() throws Exception {
		objectPool.returnObject(CONNECTION.get());
		CONNECTION.remove();
	}
}