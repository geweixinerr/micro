package com.js.port.message.manager.impl;

import com.js.port.message.bean.dto.mq.Message;
import com.js.port.message.manager.MessageManager;

import io.netty.channel.Channel;

/**
 * 消息管理-邮箱平台
 * 
 * @author gewx
 **/
public class EmailMessageManagerImpl implements MessageManager {

	@Override
	public void sendMessageToDept(String message, Channel channel) {
		// TODO Auto-generated method stub

	}

	@Override
	public void sendMessageToDept(String message, String accNo) {
		// TODO Auto-generated method stub

	}

	@Override
	public void sendMessageToAcc(String message, String... accNo) {
		// TODO Auto-generated method stub

	}
	
	@Override
	public void insert(Message message) {

	}
}
