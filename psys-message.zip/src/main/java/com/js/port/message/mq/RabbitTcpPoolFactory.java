package com.js.port.message.mq;

import org.apache.commons.pool2.BasePooledObjectFactory;
import org.apache.commons.pool2.PooledObject;
import org.apache.commons.pool2.impl.DefaultPooledObject;

import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

/**
 * mq tcp连接对象池
 * 
 * @author gewx
 **/
public final class RabbitTcpPoolFactory extends BasePooledObjectFactory<Connection> {

	private final ConnectionFactory factory;

	public RabbitTcpPoolFactory(ConnectionFactory factory) {
		this.factory = factory;
	}

	@Override
	public Connection create() throws Exception {
		return factory.newConnection();
	}

	@Override
	public PooledObject<Connection> wrap(Connection connection) {
		return new DefaultPooledObject<Connection>(connection);
	}

	@Override
	public void destroyObject(PooledObject<Connection> connection) throws Exception {
		connection.getObject().close();
	}
}
