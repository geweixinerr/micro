package com.js.port.message.bean.po;

import java.util.Date;

import com.js.port.message.bean.BaseEntity;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 平台消息
 * 
 * @author gewx
 **/
@Setter
@Getter
@ToString
public class MCloudMessage extends BaseEntity {

	private static final long serialVersionUID = 2237194516414876246L;

	/**
	 * 主键Id
	 **/
	private Long id;

	/**
	 * 消息标题
	 **/
	private String title;

	/**
	 * 消息类型
	 **/
	private String msgType;

	/**
	 * 消息内容
	 **/
	private String content;

	/**
	 * 消息状态
	 **/
	private String state;

	/**
	 * 消息路由
	 **/
	private String route;

	/**
	 * 消息路由参数
	 **/
	private String routeArg;

	/**
	 * 消息发送账号
	 **/
	private String sendAccno;

	/**
	 * 消息发送时间
	 **/
	private Date sendTime;

	/**
	 * 接收账号
	 **/
	private String receiveAccno;

	/**
	 * 消息接收时间
	 * **/
	private Date receiveTime;
	
	/**
	 * 接收账号组织编码
	 **/
	private String receiveOrgCode;

	/**
	 * 消息读取时间
	 **/
	private Date readerTime;

	/**
	 * 接收目标枚举, ReceiveTargetEnum
	 **/
	private String receiveTarget;

	/**
	 * 消息读取状态
	 **/
	private String isReader;

	/**
	 * 备注
	 **/
	private String remark;

}
