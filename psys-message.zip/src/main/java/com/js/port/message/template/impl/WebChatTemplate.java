package com.js.port.message.template.impl;

import com.js.port.message.template.MessageTemplate;

/**
 * 微信消息模板
 * 
 * @author gewx
 * **/
public final class WebChatTemplate implements MessageTemplate {

	private static final long serialVersionUID = 6978078189445736599L;

}
