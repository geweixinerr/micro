package com.js.port.message.commons.util;

import com.js.port.message.commons.annotation.ThreadSafe;
import com.js.port.message.commons.jwt.Jwt;
import org.springframework.data.redis.core.RedisTemplate;

import java.util.concurrent.TimeUnit;

/**
 * Jwt工具类
 * 
 * @author gewx
 **/
@ThreadSafe
public final class JwtUtils {

	/**
	 * 解析token
	 * 
	 * @author gewx
	 * @param token
	 * @return jwtBean
	 **/
	public static Jwt.JwtBean parseToken(String token) {
		String strJsonToken = JasyptUtils.decrypt(token);
		return JSONUtils.NON_NULL.toJavaObject(strJsonToken, Jwt.JwtBean.class);
	}

	/**
	 * 本地token鉴权
	 * 
	 * @author gewx
	 * @param token
	 * @return true 验证通过, false 验证不通过,token已过期
	 **/
	public static boolean verifyToken(String token) {
		Jwt.JwtBean bean = parseToken(token);
        return bean.getExpiresDate() > System.currentTimeMillis();
	}

	/**
	 * 本地token鉴权
	 * 
	 * @author gewx
	 * @param bean token对象
	 * @return true 验证通过, false 验证不通过,token已过期
	 **/
	public static boolean verifyToken(Jwt.JwtBean bean) {
        return bean.getExpiresDate() > System.currentTimeMillis();
	}

	/**
	 * 远程token鉴权
	 * 
	 * @author gewx
	 * @param token
	 * @return true 验证通过, false 验证不通过
	 **/
	public static boolean remoteVerifyToken(String token) {
		Jwt.JwtBean bean = parseToken(token);
		RedisTemplate<String, String> redisTemplate = SpringUtils.getBean("redisTemplate");
		return redisTemplate.opsForValue().setIfAbsent(token, "true",
				(bean.getExpiresDate() - System.currentTimeMillis()) / 1000 + 60, TimeUnit.SECONDS);
	}
}
