package com.js.port.message.template.impl;

import com.js.port.message.template.MessageTemplate;

/**
 * 短信模板
 * 
 * @author gewx
 * **/
public final class SmsMessageTemplate implements MessageTemplate {

	private static final long serialVersionUID = 1080451190250786528L;
}
