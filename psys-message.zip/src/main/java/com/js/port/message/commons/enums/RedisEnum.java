package com.js.port.message.commons.enums;

import lombok.Getter;

/**
 * redis缓存key枚举
 * 
 * @author gewx
 **/
@Getter
public enum RedisEnum {

	REDIS_ACCNO("PSYS_MASTER_ACCNO_", "用户明细前缀"),
	
	REDIS_ONLINE_ACC_DEPT("PSYS_ONLINE_ACC_DEPT", "在线部门用户"),

	PSYS_MASTER_LOGIN_ACCOUNT("PSYS_MASTER_LOGIN_ACCOUNT", "登录活跃用户");
	
	RedisEnum(String code, String comment) {
		this.code = code;
		this.comment = comment;
	}

	/**
	 * 编码
	 **/
	private String code;

	/**
	 * 注释
	 **/
	private String comment;
}
