package com.js.port.etl.service.business.ZeroUtil;


public interface ZeroUtilService {
	/**
	 * 插入数据
	 * @param params
	 */
	void  insertZZeroUtil( );
	void  insertZZeroUtilTdl();

}
