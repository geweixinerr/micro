package com.js.port.etl.bean.po;

import java.math.BigDecimal;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * etl台时效率设备数据
 * @author 46648
 *2020年7月2日
 *
 */
@Setter
@Getter
@ToString
public class ZEfficiency {
	/**
     * 数据记录ID
     */
    private Long id;
	
    /**
     * 设备名称
     */
    private String machine;
    
    /**
     *设备编号
     */
    private String codeMachine;
    
    /**
     * 所属公司
     */
    private String company;
    
    /**
     * 设备类别
     */
    private String machineType;
    
    /**
     * 工时
     */
    private  BigDecimal hours;
    
    /**
     * 
     */
    private  String cargo;
    
    /**
     * 工作量
     */
    private  BigDecimal factWeight;
    
    
    /**
     * 数据记录日期
     */
    private  Date tallyDate;
    
    /**
     * 数据抽取时间
     */
    private String createTime;
   
}
