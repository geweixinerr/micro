package com.js.port.etl.bean.po;

import java.math.BigDecimal;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * etl零利用率设备数据
 * @author 11942
 *2020年6月30日
 *
 */
@Setter
@Getter
@ToString
public class ZZeroUtil {
		
		/**
	     * 数据记录ID
	     */
	    private Long id;
		
	    /**
	     * 设备名称
	     */
	    private String machine;
	    
	    /**
	     *设备编号
	     */
	    private String codeMachine;
	    
	    /**
	     * 所属公司
	     */
	    private String company;
	    
	    /**
	     * 设备类别
	     */
	    private String machineType;
	    
	    /**
	     * 工时
	     */
	    private  BigDecimal hours;
	    /**
	     * 工作量
	     */
	    private  BigDecimal factWeight;
	    
	    
	    /**
	     * 数据记录日期
	     */
	    private  Date time;
	    
	    /**
	     * 数据抽取时间
	     */
	    private String createTime;

}
