package com.js.port.etl.dao.efficiency;

import com.js.port.etl.bean.po.ZEfficiency;

public interface MZEfficiencyDao {
	void insert(ZEfficiency zEfficiency);
	
	Integer checkRecordByTime(String thisTime);

	int deleteByTime(String thisTime);
	
}  
