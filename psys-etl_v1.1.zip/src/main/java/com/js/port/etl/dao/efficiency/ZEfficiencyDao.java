package com.js.port.etl.dao.efficiency;

import java.util.List;
import java.util.Map;

public interface ZEfficiencyDao {
	List<Map<String,Object>> queryAll();
	
	List<Map<String,Object>> queryAllTdl();
	
	List<Map<String,Object>> queryByDate();
}
