package com.js.port.etl.dao.config;

import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;

/**
 * 数据源动态切换路由
 * 
 * @author gewx
 **/
public class RoutingDataSource extends AbstractRoutingDataSource {

	/**
	 * @author gewx
	 * @return 返回路由数据源
	 **/
	@Override
	protected Object determineCurrentLookupKey() {
		return RoutingDataSourceContext.getDataSourceRoutingKey();
	}
}
