package com.js.port.etl.service.business.ZeroUtil.impl;

import static com.js.port.etl.commons.util.StringUtil.*;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import com.js.port.etl.dao.DaoExecutors;
import com.js.port.etl.dao.config.DynamicDataSourceEnum;
import com.js.port.etl.dao.zeroUtil.MZeroUtilDao;

import com.js.port.etl.dao.zeroUtil.ZeroUtilDao;
import com.js.port.etl.service.business.ZeroUtil.ZeroUtilService;

import cn.hutool.core.lang.Snowflake;

import com.js.port.etl.bean.po.ZZeroUtil;
import com.js.port.etl.commons.log.MicroLogger;
import com.js.port.etl.commons.util.SpringUtils;

@Service
public class ZeroUtilServiceImpl implements ZeroUtilService {

	/**
	 * 日志组件
	 */
	private static final MicroLogger LOGGER = new MicroLogger(ZeroUtilServiceImpl.class);

	@Autowired
	private ZeroUtilDao zeroUtilDao;

	@Autowired
	private MZeroUtilDao mZeroUtilDao;

	@Autowired
	private Snowflake snowflake;

	/**
	 * 查询零利用率设备及相关信息
	 */
	@Autowired
	private DaoExecutors executors;

	/**
	 * 插入数据表Z_ZeroUtil
	 * 
	 */
	@Override
	public void insertZZeroUtil() {
		final String methodName = "insertZZeroUtil";
		LOGGER.enter(methodName, "业务执行");
		List<Map<String, Object>> slaveList = executors.routing(DynamicDataSourceEnum.SLAVE_NHARBOR).execute(() -> {
			return zeroUtilDao.queryAll();
		});

		ZeroUtilServiceImpl zeroUtilService = SpringUtils.getBean(ZeroUtilServiceImpl.class);
		zeroUtilService.batchSave(slaveList);

		LOGGER.exit(methodName, StringUtils.EMPTY);
	}

	@Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
	public void batchSave(List<Map<String, Object>> slaveList) {
		String thisTime = new SimpleDateFormat("yyyy-MM-dd").format(new Date());

		// 查询当前时间是否存在
		Integer count = mZeroUtilDao.checkRecordByTime(thisTime);
		if (count > 0) {
			mZeroUtilDao.deleteByTime(thisTime);
		}
		// 构建实体，执行插入逻辑
		for (int n = 0; n < slaveList.size(); n++) {
			ZZeroUtil zZeroUtil = new ZZeroUtil();
			zZeroUtil.setId(snowflake.nextId());
			zZeroUtil.setMachine(getString(slaveList.get(n).get("MACHINE")));
			zZeroUtil.setCodeMachine(getString(slaveList.get(n).get("CODE_MACHINE")));
			zZeroUtil.setCompany(getString(slaveList.get(n).get("COMPANY")));
			zZeroUtil.setMachineType(getString(slaveList.get(n).get("MACHINETYPE")));
			zZeroUtil.setHours((BigDecimal) slaveList.get(n).get("HOURS"));
			zZeroUtil.setFactWeight((BigDecimal) slaveList.get(n).get("FACTWEIGHT"));
			zZeroUtil.setTime((Date) (slaveList.get(n).get("TALLYDATE")));
			zZeroUtil.setCreateTime(thisTime);
			mZeroUtilDao.insert(zZeroUtil);
		}
	}

	/**
	 * 插入数据表Z_ZeroUtil 三天前数据
	 * 
	 */
	@Override
	public void insertZZeroUtilTdl() {
		final String methodName = "insertZZeroUtilTdl";
		LOGGER.enter(methodName, "业务执行");
		List<Map<String, Object>> slaveList = executors.routing(DynamicDataSourceEnum.SLAVE_NHARBOR).execute(() -> {
			return zeroUtilDao.queryAllTdl();
		});

		ZeroUtilServiceImpl zeroUtilService = SpringUtils.getBean(ZeroUtilServiceImpl.class);
		zeroUtilService.TDL(slaveList);

		LOGGER.exit(methodName, StringUtils.EMPTY);
	}

	@Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
	public void TDL(List<Map<String, Object>> slaveList) {

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

		Calendar c = Calendar.getInstance();
		c.add(Calendar.DATE, -2);
		Date time = c.getTime();
		String preDay = sdf.format(time);

		// 查询当前时间三天前是否存在
		Integer count = mZeroUtilDao.checkRecordByTime(preDay);
		if (count > 0) {
			mZeroUtilDao.deleteByTime(preDay);
		}
		// 构建实体，执行插入逻辑
		for (int n = 0; n < slaveList.size(); n++) {
			ZZeroUtil zZeroUtil = new ZZeroUtil();
			zZeroUtil.setId(snowflake.nextId());
			zZeroUtil.setMachine(getString(slaveList.get(n).get("MACHINE")));
			zZeroUtil.setCodeMachine(getString(slaveList.get(n).get("CODE_MACHINE")));
			zZeroUtil.setCompany(getString(slaveList.get(n).get("COMPANY")));
			zZeroUtil.setMachineType(getString(slaveList.get(n).get("MACHINETYPE")));
			zZeroUtil.setHours((BigDecimal) slaveList.get(n).get("HOURS"));
			zZeroUtil.setFactWeight((BigDecimal) slaveList.get(n).get("FACTWEIGHT"));
			zZeroUtil.setTime((Date) (slaveList.get(n).get("TALLYDATE")));
			zZeroUtil.setCreateTime(preDay);
			mZeroUtilDao.insert(zZeroUtil);
		}
	}
}
