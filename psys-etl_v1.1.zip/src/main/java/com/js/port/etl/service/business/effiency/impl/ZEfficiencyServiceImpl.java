package com.js.port.etl.service.business.effiency.impl;

import static com.js.port.etl.commons.util.StringUtil.getString;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import com.js.port.etl.bean.po.ZEfficiency;
import com.js.port.etl.commons.log.MicroLogger;
import com.js.port.etl.commons.util.SpringUtils;
import com.js.port.etl.dao.DaoExecutors;
import com.js.port.etl.dao.config.DynamicDataSourceEnum;
import com.js.port.etl.dao.efficiency.MZEfficiencyDao;
import com.js.port.etl.dao.efficiency.ZEfficiencyDao;
import com.js.port.etl.service.business.effiency.ZEfficiencyService;

import cn.hutool.core.lang.Snowflake;

@Service
public class ZEfficiencyServiceImpl implements ZEfficiencyService {
	/**
	 * 日志组件
	 */
	private static final MicroLogger LOGGER = new MicroLogger(ZEfficiencyServiceImpl.class);

	@Autowired
	private ZEfficiencyDao zEfficiencyDao;

	@Autowired
	private MZEfficiencyDao mZEfficiencyDao;
	@Autowired
	private Snowflake snowflake;

	/**
	 * 查询台时效率设备及相关信息
	 */
	@Autowired
	private DaoExecutors executors;

	/**
	 * 插入数据表Z_ZeroUtil
	 * 
	 */	
	@Override
	public void insertZEfficiency() {
		final String methodName = "insertZEfficiency";
		LOGGER.enter(methodName, "业务执行");
		List<Map<String, Object>> slaveList = executors.routing(DynamicDataSourceEnum.SLAVE_NHARBOR).execute(() -> {
			return zEfficiencyDao.queryAll();
		});
		
		ZEfficiencyServiceImpl zEfficiencyService = SpringUtils.getBean(ZEfficiencyServiceImpl.class);
		zEfficiencyService.batchSave(slaveList);	
		
		LOGGER.exit(methodName, StringUtils.EMPTY);
}
	
	@Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
	public void batchSave(List<Map<String, Object>> slaveList) {
		String thisTime = new SimpleDateFormat("yyyy-MM-dd").format(new Date());

		// 查询当前时间是否存在
		Integer count = mZEfficiencyDao.checkRecordByTime(thisTime);
		if (count > 0) {
			mZEfficiencyDao.deleteByTime(thisTime);
		}
		// 构建实体，执行插入逻辑
		for (int n = 0; n < slaveList.size(); n++) {
			
			ZEfficiency zEfficiency = new ZEfficiency();
			zEfficiency.setId(snowflake.nextId());
			zEfficiency.setMachine(getString(slaveList.get(n).get("MACHINE")));
			zEfficiency.setCodeMachine(getString(slaveList.get(n).get("CODE_MACHINE")));
			zEfficiency.setCompany(getString(slaveList.get(n).get("COMPANY")));
			zEfficiency.setMachineType(getString(slaveList.get(n).get("MACHINETYPE")));
			zEfficiency.setHours((BigDecimal) slaveList.get(n).get("HOURS"));
			zEfficiency.setFactWeight((BigDecimal) slaveList.get(n).get("FACTWEIGHT"));
			zEfficiency.setTallyDate((Date)(slaveList.get(n).get("TALLYDATE")));
			zEfficiency.setCargo(getString(slaveList.get(n).get("CARGO")));
			zEfficiency.setCreateTime(thisTime);
			mZEfficiencyDao.insert(zEfficiency);	
		}		
	}
	/**
	 * 插入数据表Z_Efficiency 三天前数据
	 * 
	 */	
	@Override
	public void insertZEfficiencyTdl() {
		final String methodName = "insertZEfficiencyTdl";
		LOGGER.enter(methodName, "业务执行");
		List<Map<String, Object>> slaveList = executors.routing(DynamicDataSourceEnum.SLAVE_NHARBOR).execute(() -> {
			return zEfficiencyDao.queryAllTdl();
		});

		
		ZEfficiencyServiceImpl zEfficiencyService = SpringUtils.getBean(ZEfficiencyServiceImpl.class);
		zEfficiencyService.TDL(slaveList);

		LOGGER.exit(methodName, StringUtils.EMPTY);
}
	
	@Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
	public void TDL(List<Map<String, Object>> slaveList) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");                
		  
	    Calendar c = Calendar.getInstance();           
	    c.add(Calendar.DATE, - 2);           
	    Date time = c.getTime();         
	    String preDay = sdf.format(time);

		// 查询当前时间三天前是否存在
		Integer count = mZEfficiencyDao.checkRecordByTime(preDay);
		if (count > 0) {
			mZEfficiencyDao.deleteByTime(preDay);
		}
		// 构建实体，执行插入逻辑
		for (int n = 0; n < slaveList.size(); n++) {
			
			ZEfficiency zEfficiency = new ZEfficiency();
			zEfficiency.setId(snowflake.nextId());
			zEfficiency.setMachine(getString(slaveList.get(n).get("MACHINE")));
			zEfficiency.setCodeMachine(getString(slaveList.get(n).get("CODE_MACHINE")));
			zEfficiency.setCompany(getString(slaveList.get(n).get("COMPANY")));
			zEfficiency.setMachineType(getString(slaveList.get(n).get("MACHINETYPE")));
			zEfficiency.setHours((BigDecimal) slaveList.get(n).get("HOURS"));
			zEfficiency.setFactWeight((BigDecimal) slaveList.get(n).get("FACTWEIGHT"));
			zEfficiency.setTallyDate((Date)(slaveList.get(n).get("TALLYDATE")));
			zEfficiency.setCreateTime(preDay);
			zEfficiency.setCargo(getString(slaveList.get(n).get("CARGO")));
			mZEfficiencyDao.insert(zEfficiency);	
		}		
	}
	

}
	
