package com.js.port.etl.dao;

import org.springframework.stereotype.Component;

import com.js.port.etl.commons.annotation.ThreadSafe;
import com.js.port.etl.dao.config.DynamicDataSourceEnum;
import com.js.port.etl.dao.config.RoutingDataSourceContext;

/**
 * 多数据源切换辅助执行工具类
 * 
 * @author gewx
 **/
@Component
@ThreadSafe
public final class DaoExecutors {

	/**
	 * 路由上下文对象
	 **/
	private static final ThreadLocal<String> ROUTING = ThreadLocal
			.withInitial(() -> DynamicDataSourceEnum.MASTER.getDataSourceName());

	/**
	 * 设置路由
	 * 
	 * @author gewx
	 * @param dataSourceEnum 路由枚举
	 * @return 执行器对象
	 **/
	public DaoExecutors routing(DynamicDataSourceEnum dataSourceEnum) {
		ROUTING.set(dataSourceEnum.getDataSourceName());
		return this;
	}

	/**
	 * 执行过程
	 * 
	 * @author gewx
	 * @param execute 执行对象
	 * @return T 返回结果对象
	 **/
	public <T> T execute(Execute<T> execute) {
		try {
			try (RoutingDataSourceContext ctx = new RoutingDataSourceContext(ROUTING.get())) {
				return execute.invoke();
			}
		} finally {
			after();
		}
	}

	/**
	 * 执行后置
	 **/
	private void after() {
		ROUTING.remove();
	}
}