package com.js.port.etl.dao.zeroUtil;

import java.util.List;
import java.util.Map;

public interface ZeroUtilDao {
	
	List<Map<String,Object>> queryAll();
	
	List<Map<String,Object>> queryAllTdl();
	
	
	
}
