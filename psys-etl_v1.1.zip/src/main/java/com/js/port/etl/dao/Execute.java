package com.js.port.etl.dao;

/**
 * 函数式接口
 * 
 * @author gewx
 **/
@FunctionalInterface
public interface Execute<T> {

	/**
	 * 分布式锁执行单元
	 * 
	 * 
	 * @author gewx
	 * @return 返回业务单元执行结果
	 **/
	T invoke();
}
