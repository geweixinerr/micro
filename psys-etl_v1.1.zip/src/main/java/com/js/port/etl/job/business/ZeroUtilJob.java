package com.js.port.etl.job.business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.js.port.etl.commons.log.MicroLogger;
import com.js.port.etl.service.business.ZeroUtil.ZeroUtilService;
import com.xxl.job.core.biz.model.ReturnT;
import com.xxl.job.core.handler.annotation.XxlJob;

/**
 * 零利用率设备
 * @author 11942
 *2020年6月29日
 *
 */
@Component
public class ZeroUtilJob {
	/**
	 * 日志组件
	 **/
	private static final MicroLogger LOGGER = new MicroLogger(ZeroUtilJob.class);

	@Autowired
	private ZeroUtilService zeroUtilService;

	@XxlJob(value = "zeroUtilJob")
	public ReturnT<String> execute(String params) throws Exception {
		final String methodName = "execute";
		LOGGER.enter(methodName, "零利用率设备数据读取[start]");
	
		zeroUtilService.insertZZeroUtil();
		zeroUtilService.insertZZeroUtilTdl();
		
		LOGGER.exit(methodName, "零利用率设备数据读取结束[end], result: success~");
		return ReturnT.SUCCESS;
	}

}
