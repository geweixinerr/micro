package com.js.port.etl.dao.zeroUtil;



import com.js.port.etl.bean.po.ZZeroUtil;

public interface MZeroUtilDao {
	
	int insert(ZZeroUtil zZeroUtil);

	Integer checkRecordByTime(String thisTime);

	int deleteByTime(String thisTime);

}
