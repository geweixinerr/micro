package com.js.port.etl.service.business.effiency;

public interface ZEfficiencyService {
	/**
	 * 插入数据
	 */
	void  insertZEfficiency( );
	
	void insertZEfficiencyTdl();
}
