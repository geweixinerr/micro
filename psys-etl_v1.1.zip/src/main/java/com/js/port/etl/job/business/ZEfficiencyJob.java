package com.js.port.etl.job.business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.js.port.etl.commons.log.MicroLogger;
import com.js.port.etl.service.business.effiency.ZEfficiencyService;
import com.xxl.job.core.biz.model.ReturnT;
import com.xxl.job.core.handler.annotation.XxlJob;

/**
 * 台时效率设备
 * @author 46648
 *2020年6月29日
 *
 */
@Component
public class ZEfficiencyJob {
	/**
	 * 日志组件
	 **/
	private static final MicroLogger LOGGER = new MicroLogger(ZEfficiencyJob.class);

	@Autowired
	private ZEfficiencyService zEfficiencyService;

	@XxlJob(value = "efficierncy")
	public ReturnT<String> execute(String params) throws Exception {
		final String methodName = "execute";
		LOGGER.enter(methodName, "台时效率设备数据读取[start]");
	
		zEfficiencyService.insertZEfficiency();
		zEfficiencyService.insertZEfficiencyTdl();	
		
		LOGGER.exit(methodName, "台时效率设备数据读取结束[end], result: success~");
		return ReturnT.SUCCESS;
	}
}
