package com.js.port.etl.commons.snowflake;

import cn.hutool.core.lang.Snowflake;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * 雪花算法主键生成器
 * 
 * @author liangd
 **/

@Configuration
public class SnowConfig {

//    @Value("${snow.workId}")
//    private Integer workId ;
//
//    @Value("${snow.appId}")
//    private Integer appId ;

	/**
	 * workerId ---> 终端id datacenterId--->数据中心id
	 * 
	 * @author liangd
	 * @return Snowflake
	 */
	@Bean
	public Snowflake snowflake() {
		Snowflake snowflake = new Snowflake(1, 1);
		return snowflake;
	}
}