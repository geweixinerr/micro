package com.js.port.etl.dao.config;

import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.context.annotation.Primary;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.spring.boot.autoconfigure.DruidDataSourceBuilder;
import com.js.port.etl.commons.log.MicroLogger;

/**
 * Druid多数据源配置
 * 
 * @author gewx
 **/

@Configuration
public class DruidDataSourceConfig {

	/**
	 * 日志
	 **/
	private static final MicroLogger LOGGER = new MicroLogger(DruidDataSourceConfig.class);

	@Autowired
	private DruidConfig druidConfig;

	/**
	 * ETL主库
	 * 
	 * @author gewx
	 * @throws Exception
	 * @return 主库/写数据源
	 **/
	@Bean("masterDataSource")
	@ConfigurationProperties("spring.datasource.master")
	public DataSource masterDataSource() throws Exception {
		final String methodName = "masterDataSource";
		LOGGER.info(methodName, "主数据源配置SUCCESS~");

		DruidDataSource datasource = DruidDataSourceBuilder.create().build();
		BeanUtils.copyProperties(datasource, druidConfig);
		return datasource;
	}

	/**
	 * 从库 psys-master
	 * 
	 * @author gewx
	 * @throws Exception
	 * @return 写数据源
	 */
	@Bean("slavePsysMasterDataSource")
	@ConfigurationProperties(prefix = "spring.datasource.slave-psys-master")
	DataSource slavePsysMasterDataSource() throws Exception {
		final String methodName = "slavePsysMasterDataSource";
		LOGGER.info(methodName, "从库psys-master数据源配置SUCCESS~");

		DruidDataSource datasource = DruidDataSourceBuilder.create().build();
		BeanUtils.copyProperties(datasource, druidConfig);
		return datasource;
	}

	/**
	 * 主数据源路由配置 如下配置也可以解决多数据源依赖冲突的问题:
	 * 
	 * @SpringBootApplication(exclude = {DataSourceAutoConfiguration.class})
	 **/
	@Bean
	@DependsOn({ "masterDataSource", "slavePsysMasterDataSource" })
	@Primary
	public DataSource primaryDataSource(@Autowired @Qualifier("masterDataSource") DataSource masterDataSource,
			@Autowired @Qualifier("slavePsysMasterDataSource") DataSource slavePsysMasterDataSource) {
		Map<Object, Object> map = new HashMap<>(16);
		map.put("masterDataSource", masterDataSource);
		map.put("slavePsysMasterDataSource", slavePsysMasterDataSource);
		RoutingDataSource routing = new RoutingDataSource();
		routing.setTargetDataSources(map);
		return routing;
	}

	@Bean
	public DruidConfig druidConfig() {
		return new DruidConfig();
	}
}
