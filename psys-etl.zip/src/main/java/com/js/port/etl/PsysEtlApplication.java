package com.js.port.etl;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication()
@MapperScan(basePackages = { "com.js.port.etl.dao" })
public class PsysEtlApplication {

	public static void main(String[] args) {
		SpringApplication.run(PsysEtlApplication.class, args);
	}
	
}
