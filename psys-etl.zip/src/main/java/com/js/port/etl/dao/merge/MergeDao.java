package com.js.port.etl.dao.merge;

import java.util.List;
import java.util.Map;

public interface MergeDao {

	List<Map<String,Object>> queryAll();
}
