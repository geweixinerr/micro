package com.js.port.etl.dao.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import lombok.Getter;
import lombok.Setter;

@ConfigurationProperties("spring.datasource.druid")
@Setter
@Getter
public class DruidConfig {

    private boolean asyncInit;

    private int initialSize;
    
    private int maxActive;
    
    private int minIdle;
    
    private int maxWait;
    
    private boolean useUnfairLock;
    
    private boolean poolPreparedStatements;
    
    private int maxOpenPreparedStatements;
    
    private int timeBetweenEvictionRunsMillis;
    
    private int minEvictableIdleTimeMillis;
    
    private int maxEvictableIdleTimeMillis;
    
    private String validationQuery;
    
    private boolean testOnBorrow;
    
    private boolean testWhileIdle;
    
    private boolean testOnReturn;
}
