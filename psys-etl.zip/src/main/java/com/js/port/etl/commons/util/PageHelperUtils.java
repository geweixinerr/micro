package com.js.port.etl.commons.util;

import static org.apache.commons.lang3.StringUtils.*;

import java.util.function.Supplier;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.js.port.etl.commons.annotation.ThreadSafe;
import com.js.port.etl.commons.exception.BusinessRuntimeException;
import com.js.port.etl.commons.page.PageParameter;
import com.js.port.etl.commons.page.Pages;

/**
 * 分页工具类,基于PageHelper
 * 
 * @author gewx
 **/
@ThreadSafe
public final class PageHelperUtils {

	private static int ZERO = 0;
	
	/**
	 * 通用分页方法
	 * 
	 * @author gewx
	 * @param parameter 分页参数
	 * @param pageResult 分页数据集
	 * @return void
	 **/
	public static <T> Pages<T> limit(PageParameter parameter, Supplier<Page<T>> pageResult) {
		if (parameter.getStartpage() == null) {
			throw new BusinessRuntimeException("页码必填");
		}
		
		if (parameter.getPagesize() == null) {
			throw new BusinessRuntimeException("页行必填");
		}
		
		if (parameter.getPagesize().intValue() == ZERO) {
			throw new BusinessRuntimeException("页行必须大于0");
		}
		
		PageHelper.startPage(parameter.getStartpage(), parameter.getPagesize());
		if (isNotBlank(parameter.getSortname())) {
			PageHelper.orderBy(parameter.getSortname());
			if (parameter.isSymbol()) {
				PageHelper.orderBy(parameter.getSortname() + " DESC");
			}
		}

		Page<T> page = pageResult.get();
		Pages<T> pages = new Pages<T>();
		pages.setTotalPageNum(page.getPages());
		pages.setTotalNum(page.getTotal());
		pages.setPageNum(page.getPageNum());
		pages.setPageSize(page.getPageSize());
		pages.setPages(page.getResult());
		return pages;
	}
}
