package com.js.port.etl.service.merge;

import java.util.List;
import java.util.Map;

public interface MergeService {

	List<Map<String,Object>> queryAll();
}
