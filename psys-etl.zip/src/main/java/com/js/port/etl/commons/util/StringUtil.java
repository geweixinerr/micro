package com.js.port.etl.commons.util;

import org.apache.commons.lang3.StringUtils;

import com.js.port.etl.commons.annotation.ThreadSafe;
import com.js.port.etl.commons.exception.NumberConvertException;

import java.io.PrintWriter;
import java.io.StringWriter;

/**
 * 字符串操作辅助类
 * 
 * @author gewx
 **/
@ThreadSafe
public final class StringUtil {

	/**
	 * 获取对象的字符串
	 * 
	 * @author gewx
	 * @param obj 需要转换的对象
	 * @return string
	 **/
	public static String getString(Object obj) {
		if (obj == null) {
			return StringUtils.EMPTY;
		} else {
			return obj.toString();
		}
	}

	/**
	 * 获取Int数值
	 * 
	 * @author gewx
	 * @param obj 需要转换的对象
	 * @return Integer
	 * @throws IllegalAccessException
	 **/
	public static Integer getInt(Object obj) {
		String val = getString(obj);
		if (StringUtils.isNumeric(val)) {
			return Integer.parseInt(val);
		} else {
			throw new NumberConvertException("转换数值类型失败~");
		}
	}

	/**
	 * 获取Long数值
	 * 
	 * @author gewx
	 * @param obj 需要转换的对象
	 * @return Long
	 * @throws IllegalAccessException
	 **/
	public static Long getLong(Object obj) {
		String val = getString(obj);
		if (StringUtils.isNumeric(val)) {
			return Long.parseLong(val);
		} else {
			throw new NumberConvertException("转换数值类型失败~");
		}
	}
	
	/**
	 * 异常栈字符串输出
	 * 
	 * @author gewx
	 * @param throwable 异常对象
	 * @return String
	 **/
	public static String getErrorText(Throwable throwable) {
		if (throwable == null) {
			return "ERROR,throwable is NULL!";
		}

		try (StringWriter strWriter = new StringWriter(512); PrintWriter writer = new PrintWriter(strWriter)) {
			throwable.printStackTrace(writer);
			StringBuffer sb = strWriter.getBuffer();
			return sb.toString();
		} catch (Exception ex) {
			return "ERROR!";
		}
	}
}
