package com.js.port.etl.service.merge.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.js.port.etl.dao.DaoExecutors;
import com.js.port.etl.dao.config.DynamicDataSourceEnum;
import com.js.port.etl.dao.merge.MergeDao;
import com.js.port.etl.service.merge.MergeService;

@Service
public class MergeServiceImpl implements MergeService {

	@Autowired
	private MergeDao mergeDao;
	
	@Autowired
	private DaoExecutors executors;
	
	@Override
	public List<Map<String, Object>> queryAll() {
		List<Map<String,Object>> masterList = executors.execute(() -> {
			return mergeDao.queryAll();
		});
		System.out.println("主数据源: " + masterList);
		
		List<Map<String,Object>> slaveList = executors.routing(DynamicDataSourceEnum.SLAVE_PSYS_MASTER).execute(() -> {
			return mergeDao.queryAll();
		});
		System.out.println("从数据源: " + slaveList);
		
		return null;
	}
}
