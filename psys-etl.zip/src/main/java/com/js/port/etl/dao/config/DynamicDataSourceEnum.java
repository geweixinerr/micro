package com.js.port.etl.dao.config;

import lombok.Getter;

/**
 * 数据源枚举
 * 
 * @author gewx
 **/
@Getter
public enum DynamicDataSourceEnum {

	MASTER("masterDataSource"), SLAVE_PSYS_MASTER("slavePsysMasterDataSource");

	DynamicDataSourceEnum(String dataSourceName) {
		this.dataSourceName = dataSourceName;
	}

	private String dataSourceName;
}
