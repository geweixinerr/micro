package com.js.port.etl.dao.config;

import net.logstash.logback.encoder.org.apache.commons.lang3.ObjectUtils;

/**
 * 数据源路由上下文
 * 
 * @author gewx
 **/
public final class RoutingDataSourceContext implements AutoCloseable {

	/**
	 * 数据源载体
	 **/
	private static final ThreadLocal<String> threadLocalDataSourceKey = new ThreadLocal<>();

	public static String getDataSourceRoutingKey() {
		return ObjectUtils.defaultIfNull(threadLocalDataSourceKey.get(),
				DynamicDataSourceEnum.MASTER.getDataSourceName());
	}

	public RoutingDataSourceContext(String key) {
		threadLocalDataSourceKey.set(key);
	}

	public void close() {
		threadLocalDataSourceKey.remove();
	}
}