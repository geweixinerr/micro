package com.js.port.etl.dao.config;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

/**
 * 切点配置
 * 
 * @author gewx
 **/
@Aspect
@Component
public class RoutingAspect {

	/**
	 * 切点
	 * 
	 * @author gewx
	 * @param routingWith 注解对象
	 * @return 返回配置数据源
	 **/
	@Around("@annotation(routingWith)")
	public Object routingWithDataSource(ProceedingJoinPoint joinPoint, RoutingWith routingWith) throws Throwable {
		String key = routingWith.value().getDataSourceName();
		try (RoutingDataSourceContext ctx = new RoutingDataSourceContext(key)) {
			return joinPoint.proceed();
		}
	}
}
